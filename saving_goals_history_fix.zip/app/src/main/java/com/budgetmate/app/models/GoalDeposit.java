package com.budgetmate.app.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "goal_deposits")
public class GoalDeposit {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private int goalId;       // foreign key to SavingGoal
    private double amount;
    private String source;    // "Wallet" or "Bank"
    private long date;        // epoch millis

    public GoalDeposit(int goalId, double amount, String source, long date) {
        this.goalId = goalId;
        this.amount = amount;
        this.source = source;
        this.date   = date;
    }

    public int getId()            { return id; }
    public void setId(int id)     { this.id = id; }
    public int getGoalId()        { return goalId; }
    public void setGoalId(int v)  { this.goalId = v; }
    public double getAmount()     { return amount; }
    public void setAmount(double v){ this.amount = v; }
    public String getSource()     { return source; }
    public void setSource(String v){ this.source = v; }
    public long getDate()         { return date; }
    public void setDate(long v)   { this.date = v; }
}
