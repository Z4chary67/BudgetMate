package com.budgetmate.app.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;
import com.budgetmate.app.R;
import com.budgetmate.app.databinding.ItemSavingGoalBinding;
import com.budgetmate.app.models.GoalDeposit;
import com.budgetmate.app.models.SavingGoal;
import com.budgetmate.app.utils.CurrencyFormatter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SavingGoalAdapter extends RecyclerView.Adapter<SavingGoalAdapter.ViewHolder> {

    public interface OnDeleteClickListener  { void onDelete(SavingGoal goal); }
    public interface OnAddAmountListener    { void onAddAmount(SavingGoal goal, double amount, String source); }
    public interface OnGetDepositsListener  { LiveData<List<GoalDeposit>> getDeposits(int goalId); }

    private List<SavingGoal> goals = new ArrayList<>();
    private final OnDeleteClickListener  deleteListener;
    private final OnAddAmountListener    addAmountListener;
    private final OnGetDepositsListener  depositsListener;
    private final LifecycleOwner         lifecycleOwner;

    public SavingGoalAdapter(OnDeleteClickListener deleteListener,
                              OnAddAmountListener addAmountListener,
                              OnGetDepositsListener depositsListener,
                              LifecycleOwner lifecycleOwner) {
        this.deleteListener   = deleteListener;
        this.addAmountListener = addAmountListener;
        this.depositsListener  = depositsListener;
        this.lifecycleOwner    = lifecycleOwner;
    }

    public void setGoals(List<SavingGoal> goals) {
        this.goals = goals != null ? goals : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(ItemSavingGoalBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(goals.get(position));
    }

    @Override
    public int getItemCount() { return goals.size(); }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemSavingGoalBinding b;
        private String selectedSource = "Wallet";
        private boolean historyVisible = false;

        ViewHolder(ItemSavingGoalBinding b) {
            super(b.getRoot());
            this.b = b;
        }

        void bind(SavingGoal goal) {
            selectedSource = "Wallet";
            historyVisible = false;
            b.historyContainer.setVisibility(View.GONE);
            b.tvToggleHistory.setText("Show ▾");
            setSourceUI("Wallet");

            b.tvGoalName.setText(goal.getEmoji() + "  " + goal.getName());
            b.tvSavedAmount.setText(CurrencyFormatter.format(goal.getSavedAmount()));
            b.tvTargetAmount.setText(CurrencyFormatter.format(goal.getTargetAmount()));
            b.tvPercent.setText(goal.getProgressPercent() + "%");
            b.progressBar.setProgress(goal.getProgressPercent());

            String deadline = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    .format(new Date(goal.getDeadline()));
            b.tvDeadline.setText("🗓️ " + deadline);
            b.tvRemaining.setText("Remaining: " + CurrencyFormatter.format(goal.getRemainingAmount()));

            // Progress color
            int color;
            if      (goal.getProgressPercent() >= 100) color = Color.parseColor("#00E5A0");
            else if (goal.getProgressPercent() >= 60)  color = Color.parseColor("#FFC14E");
            else                                        color = Color.parseColor("#7C6CF8");
            b.progressBar.setProgressTintList(
                android.content.res.ColorStateList.valueOf(color));

            // Toggle history
            b.tvToggleHistory.setOnClickListener(v -> {
                historyVisible = !historyVisible;
                b.historyContainer.setVisibility(historyVisible ? View.VISIBLE : View.GONE);
                b.tvToggleHistory.setText(historyVisible ? "Hide ▴" : "Show ▾");
            });

            // Load deposit history from DB via LiveData
            if (depositsListener != null) {
                depositsListener.getDeposits(goal.getId())
                    .observe(lifecycleOwner, deposits -> renderDeposits(deposits));
            }

            // Source toggle
            b.btnSourceWallet.setOnClickListener(v -> { selectedSource = "Wallet"; setSourceUI("Wallet"); });
            b.btnSourceBank.setOnClickListener(v   -> { selectedSource = "Bank";   setSourceUI("Bank");   });

            // Delete
            if (deleteListener != null) {
                b.btnDelete.setOnClickListener(v -> deleteListener.onDelete(goal));
            }

            // Add amount
            b.btnAdd.setOnClickListener(v -> {
                String amountStr = b.etAmount.getText().toString().trim();
                if (amountStr.isEmpty()) {
                    Toast.makeText(b.getRoot().getContext(),
                        "Please enter an amount", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    double amount = Double.parseDouble(amountStr);
                    if (amount <= 0) {
                        Toast.makeText(b.getRoot().getContext(),
                            "Amount must be greater than 0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (addAmountListener != null) {
                        addAmountListener.onAddAmount(goal, amount, selectedSource);
                    }
                    b.etAmount.setText("");
                    b.etAmount.clearFocus();

                    // Update card UI immediately
                    goal.setSavedAmount(goal.getSavedAmount() + amount);
                    b.tvSavedAmount.setText(CurrencyFormatter.format(goal.getSavedAmount()));
                    b.tvRemaining.setText("Remaining: " + CurrencyFormatter.format(goal.getRemainingAmount()));
                    b.progressBar.setProgress(goal.getProgressPercent());
                    b.tvPercent.setText(goal.getProgressPercent() + "%");

                    // Auto-show history after adding
                    if (!historyVisible) {
                        historyVisible = true;
                        b.historyContainer.setVisibility(View.VISIBLE);
                        b.tvToggleHistory.setText("Hide ▴");
                    }

                    Toast.makeText(b.getRoot().getContext(),
                        "₱" + String.format("%.2f", amount) + " added from " + selectedSource + " ✅",
                        Toast.LENGTH_SHORT).show();

                } catch (NumberFormatException e) {
                    Toast.makeText(b.getRoot().getContext(), "Invalid amount", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private void renderDeposits(List<GoalDeposit> deposits) {
            b.depositList.removeAllViews();

            if (deposits == null || deposits.isEmpty()) {
                b.tvNoDeposits.setVisibility(View.VISIBLE);
                return;
            }

            b.tvNoDeposits.setVisibility(View.GONE);
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.getDefault());

            for (GoalDeposit deposit : deposits) {
                // Row layout
                LinearLayout row = new LinearLayout(b.getRoot().getContext());
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
                rowParams.setMargins(0, 0, 0, dpToPx(6));
                row.setLayoutParams(rowParams);
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);

                // Source emoji
                TextView tvSource = new TextView(b.getRoot().getContext());
                tvSource.setText("Bank".equals(deposit.getSource()) ? "🏦  " : "👛  ");
                tvSource.setTextSize(13);
                tvSource.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

                // Date + source label
                TextView tvDate = new TextView(b.getRoot().getContext());
                tvDate.setText(sdf.format(new Date(deposit.getDate())) + "  (" + deposit.getSource() + ")");
                tvDate.setTextColor(Color.parseColor("#6B7A99"));
                tvDate.setTextSize(10);
                LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                tvDate.setLayoutParams(dateParams);

                // Amount
                TextView tvAmount = new TextView(b.getRoot().getContext());
                tvAmount.setText("+" + CurrencyFormatter.format(deposit.getAmount()));
                tvAmount.setTextColor(Color.parseColor("#00E5A0"));
                tvAmount.setTextSize(12);
                tvAmount.setTypeface(null, android.graphics.Typeface.BOLD);
                tvAmount.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

                row.addView(tvSource);
                row.addView(tvDate);
                row.addView(tvAmount);
                b.depositList.addView(row);
            }
        }

        private int dpToPx(int dp) {
            float density = b.getRoot().getContext().getResources().getDisplayMetrics().density;
            return Math.round(dp * density);
        }

        private void setSourceUI(String source) {
            int darkText  = Color.parseColor("#0A0E1A");
            int mutedText = Color.parseColor("#6B7A99");
            if ("Wallet".equals(source)) {
                b.btnSourceWallet.setBackgroundResource(R.drawable.bg_source_selected);
                b.btnSourceWallet.setTextColor(darkText);
                b.btnSourceBank.setBackgroundResource(R.drawable.bg_source_unselected);
                b.btnSourceBank.setTextColor(mutedText);
            } else {
                b.btnSourceBank.setBackgroundResource(R.drawable.bg_source_selected);
                b.btnSourceBank.setTextColor(darkText);
                b.btnSourceWallet.setBackgroundResource(R.drawable.bg_source_unselected);
                b.btnSourceWallet.setTextColor(mutedText);
            }
        }
    }
}
