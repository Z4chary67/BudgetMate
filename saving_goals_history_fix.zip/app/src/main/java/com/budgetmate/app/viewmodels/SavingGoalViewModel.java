package com.budgetmate.app.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.budgetmate.app.models.GoalDeposit;
import com.budgetmate.app.models.SavingGoal;
import com.budgetmate.app.repositories.GoalDepositRepository;
import com.budgetmate.app.repositories.SavingGoalRepository;
import java.util.List;

public class SavingGoalViewModel extends AndroidViewModel {

    private final SavingGoalRepository goalRepo;
    private final GoalDepositRepository depositRepo;

    public SavingGoalViewModel(Application application) {
        super(application);
        goalRepo    = new SavingGoalRepository(application);
        depositRepo = new GoalDepositRepository(application);
    }

    // Goal operations
    public void insert(SavingGoal goal)  { goalRepo.insert(goal); }
    public void update(SavingGoal goal)  { goalRepo.update(goal); }
    public void delete(SavingGoal goal)  { goalRepo.delete(goal); }

    public LiveData<List<SavingGoal>> getAllGoals()    { return goalRepo.getAllGoals(); }
    public LiveData<List<SavingGoal>> getRecentGoals(){ return goalRepo.getRecentGoals(); }

    // Deposit operations
    public void insertDeposit(GoalDeposit deposit) { depositRepo.insert(deposit); }
    public void deleteDeposit(GoalDeposit deposit) { depositRepo.delete(deposit); }

    public LiveData<List<GoalDeposit>> getDepositsForGoal(int goalId) {
        return depositRepo.getDepositsForGoal(goalId);
    }

    /**
     * Adds amount to goal's savedAmount, saves the deposit record, updates the goal.
     */
    public void addAmountToGoal(SavingGoal goal, double amount, String source) {
        goal.setSavedAmount(goal.getSavedAmount() + amount);
        goalRepo.update(goal);

        GoalDeposit deposit = new GoalDeposit(
            goal.getId(), amount, source, System.currentTimeMillis()
        );
        depositRepo.insert(deposit);
    }
}
