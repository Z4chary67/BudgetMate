package com.budgetmate.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.budgetmate.app.databinding.ItemTransactionBinding;
import com.budgetmate.app.models.Transaction;
import com.budgetmate.app.utils.CurrencyFormatter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    public interface OnDeleteClickListener { void onDelete(Transaction transaction); }

    private List<Transaction> transactions = new ArrayList<>();
    private final OnDeleteClickListener deleteListener;

    public TransactionAdapter(OnDeleteClickListener deleteListener) {
        this.deleteListener = deleteListener;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions != null ? transactions : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(ItemTransactionBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(transactions.get(position));
    }

    @Override
    public int getItemCount() { return transactions.size(); }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemTransactionBinding b;
        private boolean noteExpanded = false;

        ViewHolder(ItemTransactionBinding b) {
            super(b.getRoot());
            this.b = b;
        }

        void bind(Transaction txn) {
            noteExpanded = false;
            b.layoutNote.setVisibility(View.GONE);

            b.tvTitle.setText(txn.getTitle());
            b.tvCategory.setText(txn.getCategory());
            b.tvDate.setText(new SimpleDateFormat("MMM dd, yyyy  hh:mm a", Locale.getDefault())
                    .format(new Date(txn.getDate())));

            if ("income".equals(txn.getType())) {
                b.tvAmount.setText("+" + CurrencyFormatter.format(txn.getAmount()));
                b.tvAmount.setTextColor(0xFF00E5A0);
            } else {
                b.tvAmount.setText("-" + CurrencyFormatter.format(txn.getAmount()));
                b.tvAmount.setTextColor(0xFFFF6B6B);
            }

            b.tvCategoryIcon.setText(getCategoryEmoji(txn.getCategory(), txn.getType()));

            // Note handling
            boolean hasNote = txn.getNote() != null && !txn.getNote().trim().isEmpty();
            if (hasNote) {
                b.tvNote.setText(txn.getNote().trim());
                b.tvNoteHint.setVisibility(View.VISIBLE);

                // Tap anywhere on card to toggle note
                b.getRoot().setOnClickListener(v -> {
                    noteExpanded = !noteExpanded;
                    b.layoutNote.setVisibility(noteExpanded ? View.VISIBLE : View.GONE);
                    b.tvNoteHint.setText(noteExpanded ? "📝 note  ▴" : "📝 has note  ▾");
                });
            } else {
                b.tvNoteHint.setVisibility(View.GONE);
                b.getRoot().setOnClickListener(null);
            }

            if (deleteListener != null) {
                b.btnDelete.setOnClickListener(v -> deleteListener.onDelete(txn));
            }
        }

        private String getCategoryEmoji(String category, String type) {
            if (category == null) return "💰";
            switch (category) {
                // Expense categories
                case "Food & Dining":   return "🍔";
                case "Transportation":  return "🚗";
                case "Housing":         return "🏠";
                case "Health":          return "🏥";
                case "Education":       return "🎓";
                case "Shopping":        return "🛒";
                case "Subscriptions":   return "📱";
                case "Utilities":       return "💡";
                case "Saving Goal":     return "🎯";
                // Income categories
                case "Salary":          return "💼";
                case "Investments":     return "📈";
                case "Part Time":       return "⏰";
                case "Bonus":           return "🎁";
                case "Allowance":       return "👨‍👩‍👧";
                case "Other":           return "income".equals(type) ? "💵" : "💸";
                default:                return "💰";
            }
        }
    }
}
