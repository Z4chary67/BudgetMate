package com.budgetmate.app.activities;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.budgetmate.app.R;
import com.budgetmate.app.adapters.BudgetAdapter;
import com.budgetmate.app.databinding.FragmentBudgetBinding;
import com.budgetmate.app.models.Budget;
import com.budgetmate.app.models.Transaction;
import com.budgetmate.app.utils.NotificationHelper;
import com.budgetmate.app.viewmodels.BudgetViewModel;
import com.budgetmate.app.viewmodels.TransactionViewModel;
import java.util.Calendar;
import java.util.List;

public class BudgetFragment extends Fragment {

    private FragmentBudgetBinding binding;
    private BudgetViewModel budgetViewModel;
    private TransactionViewModel transactionViewModel;
    private BudgetAdapter adapter;
    private List<Budget> currentBudgets;
    private List<Transaction> currentTransactions;

    private static final String[] CATEGORIES = {
        "Housing", "Food & Dining", "Transportation", "Education",
        "Health", "Subscriptions", "Utilities", "Shopping", "Other"
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentBudgetBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        budgetViewModel      = new ViewModelProvider(this).get(BudgetViewModel.class);
        transactionViewModel = new ViewModelProvider(this).get(TransactionViewModel.class);

        adapter = new BudgetAdapter(budget -> budgetViewModel.delete(budget));
        binding.rvBudgets.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvBudgets.setAdapter(adapter);

        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH) + 1;
        int year  = cal.get(Calendar.YEAR);

        // Observe budgets
        budgetViewModel.getBudgetsByMonth(month, year).observe(getViewLifecycleOwner(), budgets -> {
            currentBudgets = budgets;
            recalculateAndDisplay();
        });

        // Observe transactions — whenever a new expense is added, recalculate
        transactionViewModel.getAllTransactions().observe(getViewLifecycleOwner(), transactions -> {
            currentTransactions = transactions;
            recalculateAndDisplay();
        });

        binding.btnAddBudget.setOnClickListener(v -> showAddBudgetDialog());
    }

    /**
     * Recalculates spentAmount for each budget by summing matching
     * expense transactions from the current month — no manual linking needed.
     */
    private void recalculateAndDisplay() {
        if (currentBudgets == null || currentTransactions == null) return;

        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH); // 0-based for Calendar
        int year  = cal.get(Calendar.YEAR);

        // Get start and end of current month in millis
        Calendar startCal = Calendar.getInstance();
        startCal.set(year, month, 1, 0, 0, 0);
        startCal.set(Calendar.MILLISECOND, 0);
        long monthStart = startCal.getTimeInMillis();

        Calendar endCal = Calendar.getInstance();
        endCal.set(year, month, endCal.getActualMaximum(Calendar.DAY_OF_MONTH), 23, 59, 59);
        long monthEnd = endCal.getTimeInMillis();

        double totalLimit = 0;
        double totalSpent = 0;
        int warnings = 0;

        for (Budget budget : currentBudgets) {
            // Sum all expenses in this category for the current month
            double spent = 0;
            for (Transaction t : currentTransactions) {
                if ("expense".equals(t.getType())
                        && t.getCategory().equals(budget.getCategory())
                        && t.getDate() >= monthStart
                        && t.getDate() <= monthEnd) {
                    spent += t.getAmount();
                }
            }

            // Update the budget's spent amount in DB if it changed
            if (Math.abs(budget.getSpentAmount() - spent) > 0.001) {
                budget.setSpentAmount(spent);
                budgetViewModel.update(budget);
            }

            totalLimit += budget.getLimitAmount();
            totalSpent += spent;

            // Notify if needed
            if (budget.isExceeded()) {
                NotificationHelper.showBudgetExceeded(requireContext(),
                    budget.getCategory(),
                    spent - budget.getLimitAmount());
            } else if (budget.getProgressPercent() >= 80) {
                warnings++;
            }
        }

        // Update summary row
        binding.tvTotalLimit.setText("₱" + String.format("%,.0f", totalLimit));
        binding.tvTotalSpent.setText("₱" + String.format("%,.0f", totalSpent));
        binding.tvTotalRemaining.setText("₱" + String.format("%,.0f", totalLimit - totalSpent));
        binding.tvWarnings.setText(warnings > 0 ? "⚠️ " + warnings + " budget warning(s) this month" : "");

        adapter.setBudgets(currentBudgets);
    }

    private void showAddBudgetDialog() {
        View dialogView = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_add_budget, null);

        Spinner spinnerCategory = dialogView.findViewById(R.id.spinnerCategory);
        EditText etLimit        = dialogView.findViewById(R.id.etBudgetLimit);
        EditText etCustomLabel  = dialogView.findViewById(R.id.etCustomLabel);

        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
            requireContext(), android.R.layout.simple_spinner_item, CATEGORIES);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(catAdapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                etCustomLabel.setVisibility(
                    "Other".equals(CATEGORIES[pos]) ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        new AlertDialog.Builder(requireContext())
            .setTitle("Add Budget Limit")
            .setView(dialogView)
            .setPositiveButton("Add", (dialog, which) -> {
                String category    = spinnerCategory.getSelectedItem().toString();
                String customLabel = etCustomLabel.getText().toString().trim();
                String limitStr    = etLimit.getText().toString().trim();

                if (limitStr.isEmpty()) {
                    Toast.makeText(requireContext(), "Please enter a limit amount", Toast.LENGTH_SHORT).show();
                    return;
                }

                double limit = Double.parseDouble(limitStr);
                Calendar cal = Calendar.getInstance();
                Budget budget = new Budget(
                    category, customLabel, limit,
                    cal.get(Calendar.MONTH) + 1,
                    cal.get(Calendar.YEAR)
                );
                budgetViewModel.insert(budget);
                Toast.makeText(requireContext(), "Budget limit added!", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
