package com.budgetmate.app.repositories;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.budgetmate.app.database.BudgetMateDatabase;
import com.budgetmate.app.database.GoalDepositDao;
import com.budgetmate.app.models.GoalDeposit;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GoalDepositRepository {

    private final GoalDepositDao dao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public GoalDepositRepository(Application application) {
        dao = BudgetMateDatabase.getInstance(application).goalDepositDao();
    }

    public void insert(GoalDeposit deposit) {
        executor.execute(() -> dao.insert(deposit));
    }

    public void delete(GoalDeposit deposit) {
        executor.execute(() -> dao.delete(deposit));
    }

    public LiveData<List<GoalDeposit>> getDepositsForGoal(int goalId) {
        return dao.getDepositsForGoal(goalId);
    }
}
