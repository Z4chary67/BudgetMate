package com.budgetmate.app.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.budgetmate.app.R;
import com.budgetmate.app.adapters.TransactionAdapter;
import com.budgetmate.app.adapters.SavingGoalAdapter;
import com.budgetmate.app.databinding.FragmentDashboardBinding;
import com.budgetmate.app.utils.CurrencyFormatter;
import com.budgetmate.app.utils.PinManager;
import com.budgetmate.app.viewmodels.DashboardViewModel;
import com.budgetmate.app.viewmodels.SavingGoalViewModel;
import java.util.Calendar;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private DashboardViewModel dashboardViewModel;
    private SavingGoalViewModel savingGoalViewModel;
    private TransactionAdapter transactionAdapter;
    private SavingGoalAdapter goalAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dashboardViewModel  = new ViewModelProvider(this).get(DashboardViewModel.class);
        savingGoalViewModel = new ViewModelProvider(this).get(SavingGoalViewModel.class);

        // Greeting
        String name = new PinManager(requireContext()).getUserName();
        binding.tvGreeting.setText(getTimeGreeting() + ", " + name + "!");

        // Recent Transactions adapter (no delete on dashboard)
        transactionAdapter = new TransactionAdapter(null);
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(transactionAdapter);

        // Saving Goals adapter — fully wired (delete, add amount, deposit history)
        goalAdapter = new SavingGoalAdapter(
                goal -> savingGoalViewModel.delete(goal),
                (goal, amount, source) -> savingGoalViewModel.addAmountToGoal(goal, amount, source),
                goalId -> savingGoalViewModel.getDepositsForGoal(goalId),
                getViewLifecycleOwner()
        );
        binding.rvSavingGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSavingGoals.setAdapter(goalAdapter);

        // Observe balance
        dashboardViewModel.getTotalBalance().observe(getViewLifecycleOwner(), balance ->
                binding.tvTotalBalance.setText(CurrencyFormatter.format(balance != null ? balance : 0)));

        dashboardViewModel.getTotalIncome().observe(getViewLifecycleOwner(), income ->
                binding.tvTotalIncome.setText(CurrencyFormatter.format(income != null ? income : 0)));

        dashboardViewModel.getTotalExpenses().observe(getViewLifecycleOwner(), expenses ->
                binding.tvTotalExpenses.setText(CurrencyFormatter.format(expenses != null ? expenses : 0)));

        // Observe recent transactions
        dashboardViewModel.getRecentTransactions().observe(getViewLifecycleOwner(),
                transactions -> transactionAdapter.setTransactions(transactions));

        // Observe recent goals (shows top 3, same data as Saving Goals page)
        dashboardViewModel.getRecentGoals().observe(getViewLifecycleOwner(),
                goals -> goalAdapter.setGoals(goals));

        // Quick Actions
        binding.btnAddIncome.setOnClickListener(v -> {
            android.os.Bundle args = new android.os.Bundle();
            args.putString("type", "income");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnAddExpense.setOnClickListener(v -> {
            android.os.Bundle args = new android.os.Bundle();
            args.putString("type", "expense");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnBudgetLimit.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.budgetFragment));
        binding.btnSavingGoal.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));
        binding.btnSummary.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.summaryFragment));

        binding.tvSeeAllTransactions.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.transactionsFragment));
        binding.tvSeeAllGoals.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));

        // Drawer
        binding.btnMenu.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openDrawer();
            }
        });
    }

    private String getTimeGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Good morning";
        if (hour < 17) return "Good afternoon";
        return "Good evening";
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}