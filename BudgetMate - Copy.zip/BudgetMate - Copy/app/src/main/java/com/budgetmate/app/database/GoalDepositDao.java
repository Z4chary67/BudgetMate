package com.budgetmate.app.database;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.budgetmate.app.models.GoalDeposit;
import java.util.List;

@Dao
public interface GoalDepositDao {

    @Insert
    void insert(GoalDeposit deposit);

    @Delete
    void delete(GoalDeposit deposit);

    @Query("SELECT * FROM goal_deposits WHERE goalId = :goalId ORDER BY date DESC")
    LiveData<List<GoalDeposit>> getDepositsForGoal(int goalId);
}
