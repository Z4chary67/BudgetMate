package com.budgetmate.app.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.budgetmate.app.R;
import com.budgetmate.app.adapters.BudgetAlertAdapter;
import com.budgetmate.app.adapters.TransactionAdapter;
import com.budgetmate.app.adapters.SavingGoalAdapter;
import com.budgetmate.app.databinding.FragmentDashboardBinding;
import com.budgetmate.app.models.Budget;
import com.budgetmate.app.utils.CurrencyFormatter;
import com.budgetmate.app.utils.PinManager;
import com.budgetmate.app.viewmodels.DashboardViewModel;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;
import android.widget.LinearLayout;
import java.util.Calendar;
import java.util.List;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private DashboardViewModel viewModel;
    private TransactionAdapter transactionAdapter;
    private SavingGoalAdapter goalAdapter;

    // Keep the latest alerts so the bell can show them anytime
    private List<Budget> latestAlerts;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(DashboardViewModel.class);

        // Greeting
        String name = new PinManager(requireContext()).getUserName();
        String timeGreeting = getTimeGreeting();
        binding.tvGreeting.setText(timeGreeting + ", " + name + "!");

        // Adapters
        transactionAdapter = new TransactionAdapter();
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(transactionAdapter);

        goalAdapter = new SavingGoalAdapter(null, null, null, null, getViewLifecycleOwner());
        binding.rvSavingGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSavingGoals.setAdapter(goalAdapter);

        // Balance observers
        viewModel.getTotalBalance().observe(getViewLifecycleOwner(), balance ->
            binding.tvTotalBalance.setText(CurrencyFormatter.format(balance != null ? balance : 0)));

        viewModel.getTotalIncome().observe(getViewLifecycleOwner(), income ->
            binding.tvTotalIncome.setText(CurrencyFormatter.format(income != null ? income : 0)));

        viewModel.getTotalExpenses().observe(getViewLifecycleOwner(), expenses ->
            binding.tvTotalExpenses.setText(CurrencyFormatter.format(expenses != null ? expenses : 0)));

        viewModel.getRecentTransactions().observe(getViewLifecycleOwner(), transactions ->
            transactionAdapter.setTransactions(transactions));

        viewModel.getRecentGoals().observe(getViewLifecycleOwner(), goals ->
            goalAdapter.setGoals(goals));

        // ── Budget Alert Banner + Bell ────────────────────────────────────────
        viewModel.getBudgetAlerts().observe(getViewLifecycleOwner(), alerts -> {
            latestAlerts = alerts;

            if (alerts == null || alerts.isEmpty()) {
                binding.layoutBudgetAlert.setVisibility(View.GONE);
                binding.btnNotifications.clearColorFilter();
                return;
            }

            int exceeded = 0, near = 0;
            for (Budget b : alerts) {
                if (b.isExceeded()) exceeded++;
                else near++;
            }

            // Red banner
            binding.layoutBudgetAlert.setVisibility(View.VISIBLE);
            String alertText;
            if (exceeded > 0 && near > 0) {
                alertText = exceeded + " exceeded, " + near + " near limit";
            } else if (exceeded > 0) {
                alertText = exceeded + " budget limit(s) exceeded!";
            } else {
                alertText = near + " budget(s) near limit (80%+)";
            }
            binding.tvBudgetAlert.setText(alertText);

            // Bell turns red
            binding.btnNotifications.setColorFilter(
                android.graphics.Color.parseColor("#FF6B6B"),
                android.graphics.PorterDuff.Mode.SRC_IN
            );
        });

        // Banner tap → Budget page
        binding.layoutBudgetAlert.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.budgetFragment));

        // Bell tap → show bottom sheet with the alert list
        binding.btnNotifications.setOnClickListener(v -> showNotificationSheet());

        // Quick Actions
        binding.btnAddIncome.setOnClickListener(v -> {
            Bundle args = new Bundle();
            args.putString("type", "income");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnAddExpense.setOnClickListener(v -> {
            Bundle args = new Bundle();
            args.putString("type", "expense");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnBudgetLimit.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.budgetFragment));
        binding.btnSavingGoal.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));
        binding.btnSummary.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.summaryFragment));

        binding.tvSeeAllTransactions.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.transactionsFragment));
        binding.tvSeeAllGoals.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));

        binding.btnMenu.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openDrawer();
            }
        });
    }

    /**
     * Shows a bottom sheet listing all budgets that are near (80%+) or exceeded.
     * No popup, no navigation — just a clean list right there.
     */
    private void showNotificationSheet() {
        if (!isAdded() || getContext() == null) return;

        View sheetView = LayoutInflater.from(requireContext())
                .inflate(R.layout.bottom_sheet_notifications, null);

        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        dialog.setContentView(sheetView);

        RecyclerView rvAlerts      = sheetView.findViewById(R.id.rvAlerts);
        LinearLayout layoutNoAlerts = sheetView.findViewById(R.id.layoutNoAlerts);
        TextView tvAlertCount       = sheetView.findViewById(R.id.tvAlertCount);

        BudgetAlertAdapter alertAdapter = new BudgetAlertAdapter();
        rvAlerts.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvAlerts.setAdapter(alertAdapter);

        if (latestAlerts == null || latestAlerts.isEmpty()) {
            rvAlerts.setVisibility(View.GONE);
            layoutNoAlerts.setVisibility(View.VISIBLE);
            tvAlertCount.setVisibility(View.GONE);
        } else {
            rvAlerts.setVisibility(View.VISIBLE);
            layoutNoAlerts.setVisibility(View.GONE);
            tvAlertCount.setVisibility(View.VISIBLE);
            tvAlertCount.setText(latestAlerts.size() + " alert" + (latestAlerts.size() > 1 ? "s" : ""));
            alertAdapter.setAlerts(latestAlerts);
        }

        dialog.show();
    }

    private String getTimeGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Good morning";
        if (hour < 17) return "Good afternoon";
        return "Good evening";
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
