package com.budgetmate.app.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.budgetmate.app.R;
import com.budgetmate.app.models.Budget;
import java.util.ArrayList;
import java.util.List;

public class BudgetAlertAdapter extends RecyclerView.Adapter<BudgetAlertAdapter.ViewHolder> {

    private List<Budget> alerts = new ArrayList<>();

    public void setAlerts(List<Budget> alerts) {
        this.alerts = alerts != null ? alerts : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notification_alert, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(alerts.get(position));
    }

    @Override
    public int getItemCount() {
        return alerts.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategory, tvStatus, tvSpent, tvPercent;
        ProgressBar progressBar;

        ViewHolder(View itemView) {
            super(itemView);
            tvCategory  = itemView.findViewById(R.id.tvCategory);
            tvStatus    = itemView.findViewById(R.id.tvStatus);
            tvSpent     = itemView.findViewById(R.id.tvSpent);
            tvPercent   = itemView.findViewById(R.id.tvPercent);
            progressBar = itemView.findViewById(R.id.progressBar);
        }

        void bind(Budget budget) {
            tvCategory.setText(budget.getCategory());

            int percent = Math.min(budget.getProgressPercent(), 100);
            progressBar.setProgress(percent);

            tvSpent.setText("₱" + String.format("%,.2f", budget.getSpentAmount())
                    + " of ₱" + String.format("%,.2f", budget.getLimitAmount()));
            tvPercent.setText(budget.getProgressPercent() + "%");

            if (budget.isExceeded()) {
                // Red — exceeded
                tvStatus.setText("Over!");
                tvStatus.setTextColor(Color.parseColor("#FF6B6B"));
                tvStatus.setBackgroundColor(Color.parseColor("#1FFF6B6B"));
                progressBar.setProgressTint(Color.parseColor("#FF6B6B"));
                tvPercent.setTextColor(Color.parseColor("#FF6B6B"));
            } else {
                // Yellow — near limit (80%+)
                tvStatus.setText("Caution");
                tvStatus.setTextColor(Color.parseColor("#FFC14E"));
                tvStatus.setBackgroundColor(Color.parseColor("#1FFFC14E"));
                progressBar.setProgressTint(Color.parseColor("#FFC14E"));
                tvPercent.setTextColor(Color.parseColor("#FFC14E"));
            }
        }
    }
}
