package com.budgetmate.app.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.budgetmate.app.R;
import com.budgetmate.app.adapters.TransactionAdapter;
import com.budgetmate.app.adapters.SavingGoalAdapter;
import com.budgetmate.app.databinding.FragmentDashboardBinding;
import com.budgetmate.app.models.Budget;
import com.budgetmate.app.utils.CurrencyFormatter;
import com.budgetmate.app.utils.PinManager;
import com.budgetmate.app.viewmodels.BudgetViewModel;
import com.budgetmate.app.viewmodels.DashboardViewModel;
import com.budgetmate.app.viewmodels.SavingGoalViewModel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private DashboardViewModel  dashboardViewModel;
    private SavingGoalViewModel savingGoalViewModel;
    private BudgetViewModel     budgetViewModel;
    private TransactionAdapter  transactionAdapter;
    private SavingGoalAdapter   goalAdapter;

    // Live list of budgets that are caution or exceeded
    private final List<Budget> alertBudgets = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dashboardViewModel  = new ViewModelProvider(this).get(DashboardViewModel.class);
        savingGoalViewModel = new ViewModelProvider(this).get(SavingGoalViewModel.class);
        budgetViewModel     = new ViewModelProvider(this).get(BudgetViewModel.class);

        // Greeting
        String name = new PinManager(requireContext()).getUserName();
        binding.tvGreeting.setText(getTimeGreeting() + ", " + name + "! 👋");

        // Transactions adapter
        transactionAdapter = new TransactionAdapter(null);
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(transactionAdapter);

        // Goals adapter — fully wired
        goalAdapter = new SavingGoalAdapter(
            goal -> savingGoalViewModel.delete(goal),
            (goal, amount, source) -> savingGoalViewModel.addAmountToGoal(goal, amount, source),
            goalId -> savingGoalViewModel.getDepositsForGoal(goalId),
            getViewLifecycleOwner()
        );
        binding.rvSavingGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSavingGoals.setAdapter(goalAdapter);

        // Observe balances
        dashboardViewModel.getTotalBalance().observe(getViewLifecycleOwner(), balance ->
            binding.tvTotalBalance.setText(CurrencyFormatter.format(balance != null ? balance : 0)));
        dashboardViewModel.getTotalIncome().observe(getViewLifecycleOwner(), income ->
            binding.tvTotalIncome.setText(CurrencyFormatter.format(income != null ? income : 0)));
        dashboardViewModel.getTotalExpenses().observe(getViewLifecycleOwner(), expenses ->
            binding.tvTotalExpenses.setText(CurrencyFormatter.format(expenses != null ? expenses : 0)));

        dashboardViewModel.getRecentTransactions().observe(getViewLifecycleOwner(),
            txns -> transactionAdapter.setTransactions(txns));
        dashboardViewModel.getRecentGoals().observe(getViewLifecycleOwner(),
            goals -> goalAdapter.setGoals(goals));

        // Observe budgets for this month — update badge + banners
        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH) + 1;
        int year  = cal.get(Calendar.YEAR);

        budgetViewModel.getBudgetsByMonth(month, year).observe(getViewLifecycleOwner(), budgets -> {
            alertBudgets.clear();
            int exceededCount = 0;
            int cautionCount  = 0;

            if (budgets != null) {
                for (Budget b : budgets) {
                    if (b.isExceeded()) {
                        alertBudgets.add(b);
                        exceededCount++;
                    } else if (b.getProgressPercent() >= 80) {
                        alertBudgets.add(b);
                        cautionCount++;
                    }
                }
            }

            updateBadge(exceededCount + cautionCount);
            updateBanners(exceededCount, cautionCount);
        });

        // Bell button → open bottom sheet
        binding.btnNotifications.setOnClickListener(v -> showNotifSheet());

        // Quick actions
        binding.btnAddIncome.setOnClickListener(v -> {
            Bundle args = new Bundle();
            args.putString("type", "income");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnAddExpense.setOnClickListener(v -> {
            Bundle args = new Bundle();
            args.putString("type", "expense");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnBudgetLimit.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.budgetFragment));
        binding.btnSavingGoal.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));
        binding.btnSummary.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.summaryFragment));
        binding.tvSeeAllTransactions.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.transactionsFragment));
        binding.tvSeeAllGoals.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));

        binding.btnMenu.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity)
                ((MainActivity) getActivity()).openDrawer();
        });
    }

    private void updateBadge(int count) {
        if (count > 0) {
            binding.tvNotifBadge.setVisibility(View.VISIBLE);
            binding.tvNotifBadge.setText(count > 9 ? "9+" : String.valueOf(count));
        } else {
            binding.tvNotifBadge.setVisibility(View.GONE);
        }
    }

    private void updateBanners(int exceededCount, int cautionCount) {
        if (exceededCount > 0) {
            binding.layoutBudgetAlert.setVisibility(View.VISIBLE);
            binding.tvBudgetAlert.setText(exceededCount + " budget(s) exceeded this month! Tap 🔔 for details.");
        } else {
            binding.layoutBudgetAlert.setVisibility(View.GONE);
        }

        if (cautionCount > 0) {
            binding.layoutWarning.setVisibility(View.VISIBLE);
            binding.tvWarning.setText(cautionCount + " budget(s) at 80%+ — getting close! Tap 🔔 for details.");
        } else {
            binding.layoutWarning.setVisibility(View.GONE);
        }
    }

    private void showNotifSheet() {
        BudgetNotifBottomSheet sheet = BudgetNotifBottomSheet.newInstance(alertBudgets);
        sheet.show(getChildFragmentManager(), "BudgetNotif");
    }

    private String getTimeGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Good morning";
        if (hour < 17) return "Good afternoon";
        return "Good evening";
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
