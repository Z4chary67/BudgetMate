package com.budgetmate.app.activities;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.budgetmate.app.R;
import com.budgetmate.app.models.Budget;
import com.budgetmate.app.utils.CurrencyFormatter;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import java.util.ArrayList;
import java.util.List;

public class BudgetNotifBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_BUDGETS = "budgets_data";

    // Pass alert budgets as simple string arrays to avoid Parcelable
    private List<Budget> alertBudgets = new ArrayList<>();

    public static BudgetNotifBottomSheet newInstance(List<Budget> budgets) {
        BudgetNotifBottomSheet sheet = new BudgetNotifBottomSheet();
        sheet.alertBudgets = budgets;
        return sheet;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_notifications, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        LinearLayout notifList   = view.findViewById(R.id.notifList);
        LinearLayout layoutEmpty = view.findViewById(R.id.layoutEmpty);
        TextView tvDismissAll    = view.findViewById(R.id.tvDismissAll);

        tvDismissAll.setOnClickListener(v -> dismiss());

        if (alertBudgets == null || alertBudgets.isEmpty()) {
            layoutEmpty.setVisibility(View.VISIBLE);
            notifList.setVisibility(View.GONE);
            return;
        }

        layoutEmpty.setVisibility(View.GONE);
        notifList.setVisibility(View.VISIBLE);

        for (Budget budget : alertBudgets) {
            View card = buildNotifCard(budget);
            notifList.addView(card);
        }
    }

    private View buildNotifCard(Budget budget) {
        boolean exceeded = budget.isExceeded();

        // Outer card container
        LinearLayout card = new LinearLayout(requireContext());
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackgroundResource(exceeded ? R.drawable.bg_alert_red : R.drawable.bg_alert_yellow);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(cardParams);

        // Icon
        TextView tvIcon = new TextView(requireContext());
        tvIcon.setText(exceeded ? "🚨" : "⚠️");
        tvIcon.setTextSize(22);
        tvIcon.setPadding(0, 0, dp(12), 0);
        card.addView(tvIcon);

        // Text column
        LinearLayout col = new LinearLayout(requireContext());
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // Category + status label
        TextView tvTitle = new TextView(requireContext());
        String categoryEmoji = getCategoryEmoji(budget.getCategory());
        tvTitle.setText(categoryEmoji + "  " + budget.getCategory()
                + "  —  " + (exceeded ? "EXCEEDED" : "CAUTION"));
        tvTitle.setTextColor(exceeded ? Color.parseColor("#FF6B6B") : Color.parseColor("#FFC14E"));
        tvTitle.setTextSize(13);
        tvTitle.setTypeface(null, Typeface.BOLD);
        col.addView(tvTitle);

        // Detail line
        TextView tvDetail = new TextView(requireContext());
        if (exceeded) {
            double over = budget.getSpentAmount() - budget.getLimitAmount();
            tvDetail.setText("Spent " + CurrencyFormatter.format(budget.getSpentAmount())
                    + " — over by " + CurrencyFormatter.format(over));
        } else {
            tvDetail.setText("Spent " + CurrencyFormatter.format(budget.getSpentAmount())
                    + " of " + CurrencyFormatter.format(budget.getLimitAmount())
                    + "  (" + budget.getProgressPercent() + "%)");
        }
        tvDetail.setTextColor(Color.parseColor("#6B7A99"));
        tvDetail.setTextSize(11);
        tvDetail.setPadding(0, dp(3), 0, 0);
        col.addView(tvDetail);

        card.addView(col);
        return card;
    }

    private int dp(int dp) {
        float density = requireContext().getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private String getCategoryEmoji(String category) {
        if (category == null) return "💰";
        switch (category) {
            case "Housing":        return "🏠";
            case "Food & Dining":  return "🍔";
            case "Transportation": return "🚗";
            case "Education":      return "🎓";
            case "Health":         return "🏥";
            case "Subscriptions":  return "📱";
            case "Utilities":      return "💡";
            case "Shopping":       return "🛒";
            default:               return "💰";
        }
    }
}
