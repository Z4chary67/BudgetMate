package com.budgetmate.app.activities;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import com.budgetmate.app.databinding.FragmentAddTransactionBinding;
import com.budgetmate.app.models.Budget;
import com.budgetmate.app.models.Transaction;
import com.budgetmate.app.viewmodels.BudgetViewModel;
import com.budgetmate.app.viewmodels.TransactionViewModel;
import java.util.Calendar;
import java.util.List;

public class AddTransactionFragment extends Fragment {

    private FragmentAddTransactionBinding binding;
    private TransactionViewModel transactionViewModel;
    private BudgetViewModel budgetViewModel;
    private String selectedType = "income";

    // Track whether we've already fetched budgets once so we don't
    // keep re-observing after the first call.
    private boolean budgetCheckDone = false;

    private static final String[] CATEGORIES = {
        "Housing", "Food & Dining", "Transportation", "Education",
        "Health", "Subscriptions", "Utilities", "Shopping", "Other"
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentAddTransactionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        transactionViewModel = new ViewModelProvider(this).get(TransactionViewModel.class);
        budgetViewModel      = new ViewModelProvider(this).get(BudgetViewModel.class);

        // Category spinner
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
            requireContext(),
            android.R.layout.simple_spinner_item,
            CATEGORIES
        );
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerCategory.setAdapter(catAdapter);

        // Type toggle
        binding.btnTypeIncome.setOnClickListener(v -> { selectedType = "income";   updateTypeButtons(); });
        binding.btnTypeExpense.setOnClickListener(v -> { selectedType = "expense"; updateTypeButtons(); });

        if (getArguments() != null) {
            selectedType = getArguments().getString("type", "income");
        }
        updateTypeButtons();

        binding.btnSave.setOnClickListener(v -> saveTransaction());
    }

    private void saveTransaction() {
        String title     = binding.etTitle.getText().toString().trim();
        String amountStr = binding.etAmount.getText().toString().trim();
        String note      = binding.etNote.getText().toString().trim();
        String category  = binding.spinnerCategory.getSelectedItem().toString();

        if (title.isEmpty())     { binding.etTitle.setError("Please enter a title");   return; }
        if (amountStr.isEmpty()) { binding.etAmount.setError("Please enter an amount"); return; }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            binding.etAmount.setError("Invalid amount");
            return;
        }

        if (amount <= 0) { binding.etAmount.setError("Amount must be greater than 0"); return; }

        // 1. Save the transaction first
        Transaction transaction = new Transaction(
            title, amount, selectedType, category,
            System.currentTimeMillis(), note
        );
        transactionViewModel.insert(transaction);

        // 2. If expense → check budget and show popup BEFORE navigating away
        if ("expense".equals(selectedType)) {
            checkBudgetAndAlert(category, amount);
        } else {
            // Income — just go back immediately
            Toast.makeText(requireContext(), "Transaction saved!", Toast.LENGTH_SHORT).show();
            navigateBack();
        }
    }

    /**
     * Fetches the current month's budgets, computes the new spent total
     * for the affected category, and shows an alert dialog in this fragment
     * BEFORE navigating away. This way the user sees the popup immediately
     * after saving an expense — without having to visit the Budget page.
     */
    private void checkBudgetAndAlert(String category, double newAmount) {
        Calendar cal = Calendar.getInstance();
        int month = cal.get(Calendar.MONTH) + 1;
        int year  = cal.get(Calendar.YEAR);

        // Use a one-shot observer so it fires once then removes itself
        budgetViewModel.getBudgetsByMonth(month, year).observe(getViewLifecycleOwner(), budgets -> {
            // Guard: only process once
            if (budgetCheckDone) return;
            budgetCheckDone = true;

            if (budgets == null || budgets.isEmpty()) {
                // No budgets set — just go back
                Toast.makeText(requireContext(), "Transaction saved!", Toast.LENGTH_SHORT).show();
                navigateBack();
                return;
            }

            Budget matchedBudget = null;
            for (Budget b : budgets) {
                if (b.getCategory().equals(category)) {
                    matchedBudget = b;
                    break;
                }
            }

            if (matchedBudget == null) {
                // No budget for this category — just go back
                Toast.makeText(requireContext(), "Transaction saved!", Toast.LENGTH_SHORT).show();
                navigateBack();
                return;
            }

            // Compute the NEW spent total for this category from all transactions
            // (the transaction was already inserted above, so it's in the DB)
            double newSpent = matchedBudget.getSpentAmount() + newAmount;
            matchedBudget.setSpentAmount(newSpent);
            budgetViewModel.update(matchedBudget);

            double limit   = matchedBudget.getLimitAmount();
            int    percent = (int) ((newSpent / limit) * 100);

            if (newSpent > limit) {
                // EXCEEDED — show red alert dialog
                double over = newSpent - limit;
                showBudgetAlertDialog(
                    "⚠️ Budget Exceeded!",
                    "Your " + category + " budget has been exceeded by ₱"
                        + String.format("%,.2f", over) + ".\n\n"
                        + "Limit: ₱" + String.format("%,.2f", limit) + "\n"
                        + "Spent: ₱" + String.format("%,.2f", newSpent),
                    true
                );
            } else if (percent >= 80) {
                // NEAR LIMIT — show yellow warning dialog
                showBudgetAlertDialog(
                    "⚡ Budget Caution",
                    "You've used " + percent + "% of your " + category + " budget.\n\n"
                        + "Limit: ₱" + String.format("%,.2f", limit) + "\n"
                        + "Spent: ₱" + String.format("%,.2f", newSpent) + "\n"
                        + "Remaining: ₱" + String.format("%,.2f", limit - newSpent),
                    false
                );
            } else {
                // Under limit — just go back
                Toast.makeText(requireContext(), "Transaction saved!", Toast.LENGTH_SHORT).show();
                navigateBack();
            }
        });
    }

    /**
     * Shows an alert dialog to the user while still on this fragment.
     * Navigates back only after the user dismisses it.
     */
    private void showBudgetAlertDialog(String title, String message, boolean isExceeded) {
        if (!isAdded() || getContext() == null) return;

        int iconRes = isExceeded
            ? android.R.drawable.ic_dialog_alert
            : android.R.drawable.ic_dialog_info;

        new AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMessage(message)
            .setIcon(iconRes)
            .setPositiveButton("OK", (dialog, which) -> {
                dialog.dismiss();
                Toast.makeText(requireContext(), "Transaction saved!", Toast.LENGTH_SHORT).show();
                navigateBack();
            })
            .setNeutralButton("View Budgets", (dialog, which) -> {
                dialog.dismiss();
                // Navigate to budget page instead of going back
                Navigation.findNavController(requireView()).navigate(
                    com.budgetmate.app.R.id.budgetFragment);
            })
            .setCancelable(false) // force user to tap a button
            .show();
    }

    private void navigateBack() {
        if (isAdded() && getView() != null) {
            Navigation.findNavController(requireView()).navigateUp();
        }
    }

    private void updateTypeButtons() {
        int activeGreen   = android.graphics.Color.parseColor("#00E5A0");
        int activeRed     = android.graphics.Color.parseColor("#FF6B6B");
        int inactiveColor = android.graphics.Color.parseColor("#1A2235");
        int darkText      = android.graphics.Color.parseColor("#0A0E1A");
        int mutedText     = android.graphics.Color.parseColor("#6B7A99");

        boolean isIncome = "income".equals(selectedType);

        binding.btnTypeIncome.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(isIncome ? activeGreen : inactiveColor));
        binding.btnTypeIncome.setTextColor(isIncome ? darkText : mutedText);

        binding.btnTypeExpense.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(!isIncome ? activeRed : inactiveColor));
        binding.btnTypeExpense.setTextColor(!isIncome ? darkText : mutedText);

        binding.btnSave.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(isIncome ? activeGreen : activeRed));
        binding.btnSave.setTextColor(darkText);
        binding.btnSave.setText(isIncome ? "Save Income" : "Save Expense");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
