package com.budgetmate.app.viewmodels;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.budgetmate.app.models.GoalDeposit;
import com.budgetmate.app.models.SavingGoal;
import com.budgetmate.app.models.Transaction;
import com.budgetmate.app.repositories.GoalDepositRepository;
import com.budgetmate.app.repositories.SavingGoalRepository;
import com.budgetmate.app.repositories.TransactionRepository;
import java.util.List;

public class SavingGoalViewModel extends AndroidViewModel {

    private final SavingGoalRepository   goalRepo;
    private final GoalDepositRepository  depositRepo;
    private final TransactionRepository  transactionRepo;

    public SavingGoalViewModel(Application application) {
        super(application);
        goalRepo        = new SavingGoalRepository(application);
        depositRepo     = new GoalDepositRepository(application);
        transactionRepo = new TransactionRepository(application);
    }

    // Goal operations
    public void insert(SavingGoal goal) { goalRepo.insert(goal); }
    public void update(SavingGoal goal) { goalRepo.update(goal); }
    public void delete(SavingGoal goal) { goalRepo.delete(goal); }

    public LiveData<List<SavingGoal>> getAllGoals()     { return goalRepo.getAllGoals(); }
    public LiveData<List<SavingGoal>> getRecentGoals()  { return goalRepo.getRecentGoals(); }

    // Deposit operations
    public void insertDeposit(GoalDeposit deposit) { depositRepo.insert(deposit); }
    public void deleteDeposit(GoalDeposit deposit) { depositRepo.delete(deposit); }

    public LiveData<List<GoalDeposit>> getDepositsForGoal(int goalId) {
        return depositRepo.getDepositsForGoal(goalId);
    }

    /**
     * Adds amount to goal's savedAmount AND records it as an expense transaction
     * so the dashboard balance is automatically deducted.
     *
     * Category = "Saving Goal" so it appears cleanly in the transaction list.
     * Title shows which goal and which source (Bank/Wallet).
     */
    public void addAmountToGoal(SavingGoal goal, double amount, String source) {
        // 1. Update goal saved amount
        goal.setSavedAmount(goal.getSavedAmount() + amount);
        goalRepo.update(goal);

        // 2. Save deposit record (for deposit history inside goal card)
        GoalDeposit deposit = new GoalDeposit(
            goal.getId(), amount, source, System.currentTimeMillis()
        );
        depositRepo.insert(deposit);

        // 3. Record as an expense transaction so balance is deducted on dashboard
        String title = goal.getEmoji() + " " + goal.getName() + " (" + source + ")";
        Transaction transaction = new Transaction(
            title,
            amount,
            "expense",        // deducts from balance
            "Saving Goal",    // category
            System.currentTimeMillis(),
            "Goal deposit from " + source
        );
        transactionRepo.insert(transaction);
    }
}
