package com.budgetmate.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import com.budgetmate.app.R;
import com.budgetmate.app.databinding.ActivityMainBinding;
import com.budgetmate.app.utils.PinManager;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        NavHostFragment navHostFragment = (NavHostFragment)
                getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();

        // Bottom nav — each tab clears the back stack so Home always goes home
        binding.bottomNavView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            NavOptions navOptions = new NavOptions.Builder()
                .setLaunchSingleTop(true)
                .setPopUpTo(R.id.dashboardFragment, false)
                .build();

            if (id == R.id.dashboardFragment) {
                navController.navigate(R.id.dashboardFragment, null,
                    new NavOptions.Builder()
                        .setLaunchSingleTop(true)
                        .setPopUpTo(R.id.dashboardFragment, true)
                        .build());
            } else if (id == R.id.transactionsFragment) {
                navController.navigate(R.id.transactionsFragment, null, navOptions);
            } else if (id == R.id.budgetFragment) {
                navController.navigate(R.id.budgetFragment, null, navOptions);
            } else if (id == R.id.savingGoalsFragment) {
                navController.navigate(R.id.savingGoalsFragment, null, navOptions);
            } else if (id == R.id.summaryFragment) {
                navController.navigate(R.id.summaryFragment, null, navOptions);
            }
            return true;
        });

        // Keep bottom nav in sync when navigating via code (quick actions etc.)
        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
            int destId = destination.getId();
            // Only highlight bottom nav for main destinations
            if (destId == R.id.dashboardFragment
                    || destId == R.id.transactionsFragment
                    || destId == R.id.budgetFragment
                    || destId == R.id.savingGoalsFragment
                    || destId == R.id.summaryFragment) {
                binding.bottomNavView.setSelectedItemId(destId);
            }
        });

        // Drawer menu
        binding.navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_logout) {
                logout();
            }
            binding.drawerLayout.closeDrawers();
            return true;
        });
    }

    public void openDrawer() {
        binding.drawerLayout.openDrawer(binding.navigationView);
    }

    private void logout() {
        new PinManager(this).logout();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        // If not on dashboard, go back to dashboard; otherwise exit
        if (navController.getCurrentDestination() != null
                && navController.getCurrentDestination().getId() != R.id.dashboardFragment) {
            navController.navigate(R.id.dashboardFragment, null,
                new NavOptions.Builder()
                    .setLaunchSingleTop(true)
                    .setPopUpTo(R.id.dashboardFragment, true)
                    .build());
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        return navController.navigateUp() || super.onSupportNavigateUp();
    }
}
