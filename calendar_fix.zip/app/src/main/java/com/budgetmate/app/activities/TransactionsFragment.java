package com.budgetmate.app.activities;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.budgetmate.app.R;
import com.budgetmate.app.adapters.TransactionAdapter;
import com.budgetmate.app.databinding.FragmentTransactionsBinding;
import com.budgetmate.app.models.Transaction;
import com.budgetmate.app.viewmodels.TransactionViewModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class TransactionsFragment extends Fragment {

    private FragmentTransactionsBinding binding;
    private TransactionViewModel viewModel;
    private TransactionAdapter adapter;

    private String currentFilter = "all";

    // Currently displayed month/year
    private int displayMonth; // 0-based (Calendar.MONTH)
    private int displayYear;

    // Currently selected day — null means "show whole month"
    private Integer selectedDay = null;

    // Track which day cell is highlighted
    private View lastSelectedView = null;

    private static final String[] DAY_LABELS = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
    private static final String[] MONTH_NAMES = {
        "January","February","March","April","May","June",
        "July","August","September","October","November","December"
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentTransactionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(TransactionViewModel.class);

        adapter = new TransactionAdapter(transaction -> viewModel.delete(transaction));
        binding.rvTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvTransactions.setAdapter(adapter);

        // Start on current month
        Calendar now = Calendar.getInstance();
        displayMonth = now.get(Calendar.MONTH);
        displayYear  = now.get(Calendar.YEAR);

        buildDayHeaders();
        buildCalendar();
        observeTransactions();

        // Month navigation
        binding.btnPrevMonth.setOnClickListener(v -> {
            displayMonth--;
            if (displayMonth < 0) { displayMonth = 11; displayYear--; }
            selectedDay = null;
            lastSelectedView = null;
            buildCalendar();
            observeTransactions();
        });

        binding.btnNextMonth.setOnClickListener(v -> {
            // Don't allow going past current month
            Calendar now2 = Calendar.getInstance();
            if (displayYear < now2.get(Calendar.YEAR)
                    || (displayYear == now2.get(Calendar.YEAR) && displayMonth < now2.get(Calendar.MONTH))) {
                displayMonth++;
                if (displayMonth > 11) { displayMonth = 0; displayYear++; }
                selectedDay = null;
                lastSelectedView = null;
                buildCalendar();
                observeTransactions();
            }
        });

        // Clear day selection
        binding.btnClearDay.setOnClickListener(v -> {
            selectedDay = null;
            lastSelectedView = null;
            binding.btnClearDay.setVisibility(View.GONE);
            binding.tvSelectedDay.setVisibility(View.GONE);
            buildCalendar(); // redraw to remove highlight
            observeTransactions();
        });

        // Filter buttons
        binding.btnFilterAll.setOnClickListener(v     -> setFilter("all"));
        binding.btnFilterIncome.setOnClickListener(v  -> setFilter("income"));
        binding.btnFilterExpense.setOnClickListener(v -> setFilter("expense"));
    }

    // ─── Calendar Building ────────────────────────────────────────────────────

    private void buildDayHeaders() {
        binding.rowDayHeaders.removeAllViews();
        for (String label : DAY_LABELS) {
            TextView tv = new TextView(requireContext());
            tv.setText(label);
            tv.setTextSize(10);
            tv.setTextColor(Color.parseColor("#6B7A99"));
            tv.setGravity(android.view.Gravity.CENTER);
            tv.setTypeface(null, Typeface.BOLD);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            tv.setLayoutParams(p);
            binding.rowDayHeaders.addView(tv);
        }
    }

    private void buildCalendar() {
        binding.tvMonthYear.setText(MONTH_NAMES[displayMonth] + " " + displayYear);
        binding.calendarGrid.removeAllViews();

        Calendar cal = Calendar.getInstance();
        cal.set(displayYear, displayMonth, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1; // 0=Sun
        int daysInMonth    = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        Calendar today = Calendar.getInstance();
        int todayDay   = today.get(Calendar.DAY_OF_MONTH);
        int todayMonth = today.get(Calendar.MONTH);
        int todayYear  = today.get(Calendar.YEAR);

        int dayCounter = 1;
        lastSelectedView = null;

        // Build rows of 7
        while (dayCounter <= daysInMonth) {
            LinearLayout row = new LinearLayout(requireContext());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));

            for (int col = 0; col < 7; col++) {
                // Skip empty cells at start and end
                boolean isEmpty = (dayCounter == 1 && col < firstDayOfWeek)
                        || dayCounter > daysInMonth;

                TextView cell = new TextView(requireContext());
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1f);
                p.setMargins(dp(2), dp(2), dp(2), dp(2));
                cell.setLayoutParams(p);
                cell.setGravity(android.view.Gravity.CENTER);
                cell.setTextSize(13);

                if (isEmpty) {
                    cell.setText("");
                    cell.setBackgroundColor(Color.TRANSPARENT);
                } else {
                    final int day = dayCounter;
                    boolean isToday    = (day == todayDay && displayMonth == todayMonth && displayYear == todayYear);
                    boolean isSelected = (selectedDay != null && selectedDay == day);
                    boolean isFuture   = isFutureDay(day);

                    cell.setText(String.valueOf(day));

                    if (isSelected) {
                        cell.setBackgroundResource(R.drawable.bg_source_selected); // green circle
                        cell.setTextColor(Color.parseColor("#0A0E1A"));
                        cell.setTypeface(null, Typeface.BOLD);
                        lastSelectedView = cell;
                    } else if (isToday) {
                        cell.setBackgroundResource(R.drawable.bg_today_ring);
                        cell.setTextColor(Color.parseColor("#00E5A0"));
                        cell.setTypeface(null, Typeface.BOLD);
                    } else if (isFuture) {
                        cell.setBackgroundColor(Color.TRANSPARENT);
                        cell.setTextColor(Color.parseColor("#2A3350")); // dimmed
                    } else {
                        cell.setBackgroundResource(R.drawable.bg_category_icon);
                        cell.setTextColor(Color.parseColor("#F0F4FF"));
                    }

                    if (!isFuture) {
                        cell.setOnClickListener(v -> onDaySelected(day, cell));
                    }

                    dayCounter++;
                }

                row.addView(cell);

                if (!isEmpty) {
                    // dayCounter was already incremented above
                }
            }

            binding.calendarGrid.addView(row);
        }
    }

    private boolean isFutureDay(int day) {
        Calendar today = Calendar.getInstance();
        int todayYear  = today.get(Calendar.YEAR);
        int todayMonth = today.get(Calendar.MONTH);
        int todayDay   = today.get(Calendar.DAY_OF_MONTH);

        if (displayYear > todayYear) return true;
        if (displayYear == todayYear && displayMonth > todayMonth) return true;
        if (displayYear == todayYear && displayMonth == todayMonth && day > todayDay) return true;
        return false;
    }

    private void onDaySelected(int day, View cellView) {
        selectedDay = day;
        binding.btnClearDay.setVisibility(View.VISIBLE);

        String dateStr = MONTH_NAMES[displayMonth] + " " + day + ", " + displayYear;
        binding.tvSelectedDay.setText("Showing: " + dateStr);
        binding.tvSelectedDay.setVisibility(View.VISIBLE);

        buildCalendar(); // redraw with selection highlight
        observeTransactions();
    }

    // ─── Transaction Observation ──────────────────────────────────────────────

    private void observeTransactions() {
        // Remove all previous observers
        viewModel.getAllTransactions().removeObservers(getViewLifecycleOwner());
        viewModel.getByType("income").removeObservers(getViewLifecycleOwner());
        viewModel.getByType("expense").removeObservers(getViewLifecycleOwner());
        viewModel.getByDateRange(0, Long.MAX_VALUE).removeObservers(getViewLifecycleOwner());

        long[] range = getDateRange();
        long start = range[0];
        long end   = range[1];

        // Use date range query always, then filter by type in the observer
        viewModel.getByDateRange(start, end).observe(getViewLifecycleOwner(), transactions -> {
            if (transactions == null) { adapter.setTransactions(null); return; }

            if ("all".equals(currentFilter)) {
                adapter.setTransactions(transactions);
            } else {
                List<Transaction> filtered = new java.util.ArrayList<>();
                for (Transaction t : transactions) {
                    if (currentFilter.equals(t.getType())) filtered.add(t);
                }
                adapter.setTransactions(filtered);
            }
        });
    }

    /**
     * Returns [startMillis, endMillis] for the current selection.
     * If a day is selected → just that day.
     * If no day selected → the entire display month.
     * Records only exist within their own month — navigating to a past month
     * shows that month's data; they don't carry forward.
     */
    private long[] getDateRange() {
        Calendar start = Calendar.getInstance();
        Calendar end   = Calendar.getInstance();

        if (selectedDay != null) {
            // Single day: 00:00:00 → 23:59:59
            start.set(displayYear, displayMonth, selectedDay, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            end.set(displayYear, displayMonth, selectedDay, 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);
        } else {
            // Whole month: 1st 00:00:00 → last day 23:59:59
            start.set(displayYear, displayMonth, 1, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            int lastDay = start.getActualMaximum(Calendar.DAY_OF_MONTH);
            end.set(displayYear, displayMonth, lastDay, 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);
        }

        return new long[]{start.getTimeInMillis(), end.getTimeInMillis()};
    }

    // ─── Filter ───────────────────────────────────────────────────────────────

    private void setFilter(String filter) {
        currentFilter = filter;
        updateFilterButtons();
        observeTransactions();
    }

    private void updateFilterButtons() {
        int activeColor  = Color.parseColor("#00E5A0");
        int inactiveColor = Color.parseColor("#1A2235");
        int activeText   = Color.parseColor("#0A0E1A");
        int inactiveText = Color.parseColor("#6B7A99");

        binding.btnFilterAll.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
            "all".equals(currentFilter) ? activeColor : inactiveColor));
        binding.btnFilterAll.setTextColor("all".equals(currentFilter) ? activeText : inactiveText);

        binding.btnFilterIncome.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
            "income".equals(currentFilter) ? activeColor : inactiveColor));
        binding.btnFilterIncome.setTextColor("income".equals(currentFilter) ? activeText : inactiveText);

        binding.btnFilterExpense.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
            "expense".equals(currentFilter) ? activeColor : inactiveColor));
        binding.btnFilterExpense.setTextColor("expense".equals(currentFilter) ? activeText : inactiveText);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private int dp(int dp) {
        return Math.round(dp * requireContext().getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
