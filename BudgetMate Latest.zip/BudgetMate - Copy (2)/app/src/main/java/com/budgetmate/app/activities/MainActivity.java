package com.budgetmate.app.activities;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import com.budgetmate.app.R;
import com.budgetmate.app.databinding.ActivityMainBinding;
import com.budgetmate.app.utils.PinManager;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Get NavController safely
        NavHostFragment navHostFragment = (NavHostFragment)
                getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        if (navHostFragment == null) return;
        navController = navHostFragment.getNavController();

        // Wire bottom nav using NavigationUI — handles highlighting automatically
        NavigationUI.setupWithNavController(binding.bottomNavView, navController);

        // Override bottom nav clicks to clear back stack on every tab switch
        binding.bottomNavView.setOnItemSelectedListener(item -> {
            int destId = item.getItemId();

            // If already on this tab, do nothing
            if (navController.getCurrentDestination() != null
                    && navController.getCurrentDestination().getId() == destId) {
                return true;
            }

            NavOptions options = new NavOptions.Builder()
                    .setLaunchSingleTop(true)
                    .setPopUpTo(R.id.dashboardFragment, false)
                    .build();

            NavOptions homeOptions = new NavOptions.Builder()
                    .setLaunchSingleTop(true)
                    .setPopUpTo(R.id.dashboardFragment, true)
                    .build();

            navController.navigate(destId, null,
                    destId == R.id.dashboardFragment ? homeOptions : options);
            return true;
        });

        // Drawer logout
        binding.navigationView.setNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_logout) logout();
            binding.drawerLayout.closeDrawers();
            return true;
        });
    }

    public void openDrawer() {
        binding.drawerLayout.openDrawer(binding.navigationView);
    }

    private void logout() {
        new PinManager(this).logout();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        if (navController != null
                && navController.getCurrentDestination() != null
                && navController.getCurrentDestination().getId() != R.id.dashboardFragment) {
            navController.navigate(R.id.dashboardFragment, null,
                    new NavOptions.Builder()
                            .setLaunchSingleTop(true)
                            .setPopUpTo(R.id.dashboardFragment, true)
                            .build());
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        return navController != null && navController.navigateUp()
                || super.onSupportNavigateUp();
    }
}
