package com.budgetmate.app.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.budgetmate.app.R;
import com.budgetmate.app.databinding.FragmentSummaryBinding;
import com.budgetmate.app.models.Transaction;
import com.budgetmate.app.viewmodels.TransactionViewModel;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import java.text.SimpleDateFormat;
import java.util.*;

public class SummaryFragment extends Fragment {

    private FragmentSummaryBinding binding;
    private TransactionViewModel viewModel;
    private List<Transaction> allTransactions = new ArrayList<>();

    // Filter modes: "weekly", "monthly", "yearly"
    private String donutMode = "weekly";
    private String pieMode   = "weekly";
    private String lineMode  = "weekly";

    // Period offsets (0 = current, -1 = previous, etc.)
    private int donutOffset = 0;
    private int pieOffset   = 0;

    private static final String[] MONTH_SHORT = {
        "Jan","Feb","Mar","Apr","May","Jun",
        "Jul","Aug","Sep","Oct","Nov","Dec"
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSummaryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TransactionViewModel.class);

        viewModel.getAllTransactions().observe(getViewLifecycleOwner(), transactions -> {
            allTransactions = transactions != null ? transactions : new ArrayList<>();
            refreshAll();
        });

        wireDonutFilters();
        wirePieFilters();
        wireLineFilters();
    }

    // ─── Wire filters ─────────────────────────────────────────────────────────

    private void wireDonutFilters() {
        binding.btnDonutWeekly.setOnClickListener(v -> { donutMode = "weekly";  donutOffset = 0; refreshDonut(); updateDonutFilterUI(); });
        binding.btnDonutMonthly.setOnClickListener(v -> { donutMode = "monthly"; donutOffset = 0; refreshDonut(); updateDonutFilterUI(); });
        binding.btnDonutYearly.setOnClickListener(v -> { donutMode = "yearly";  donutOffset = 0; refreshDonut(); updateDonutFilterUI(); });
        binding.btnDonutPrev.setOnClickListener(v -> { donutOffset--; refreshDonut(); });
        binding.btnDonutNext.setOnClickListener(v -> { if (donutOffset < 0) { donutOffset++; refreshDonut(); } });
    }

    private void wirePieFilters() {
        binding.btnPieWeekly.setOnClickListener(v -> { pieMode = "weekly";  pieOffset = 0; refreshPie(); updatePieFilterUI(); });
        binding.btnPieMonthly.setOnClickListener(v -> { pieMode = "monthly"; pieOffset = 0; refreshPie(); updatePieFilterUI(); });
        binding.btnPieYearly.setOnClickListener(v -> { pieMode = "yearly";  pieOffset = 0; refreshPie(); updatePieFilterUI(); });
        binding.btnPiePrev.setOnClickListener(v -> { pieOffset--; refreshPie(); });
        binding.btnPieNext.setOnClickListener(v -> { if (pieOffset < 0) { pieOffset++; refreshPie(); } });
    }

    private void wireLineFilters() {
        binding.btnLineWeekly.setOnClickListener(v -> { lineMode = "weekly";  refreshLine(); updateLineFilterUI(); });
        binding.btnLineMonthly.setOnClickListener(v -> { lineMode = "monthly"; refreshLine(); updateLineFilterUI(); });
        binding.btnLineYearly.setOnClickListener(v -> { lineMode = "yearly";  refreshLine(); updateLineFilterUI(); });
    }

    private void refreshAll() {
        refreshDonut();
        refreshPie();
        refreshLine();
        updateDonutFilterUI();
        updatePieFilterUI();
        updateLineFilterUI();
    }

    // ─── Period label + range ─────────────────────────────────────────────────

    /** Returns [startMillis, endMillis] and sets the period label TextView */
    private long[] getRangeAndLabel(String mode, int offset, TextView labelView) {
        Calendar now = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        Calendar end   = Calendar.getInstance();

        if ("weekly".equals(mode)) {
            // Week 1 = days 1–7, Week 2 = 8–14, Week 3 = 15–21, Week 4 = 22–end
            // Current week = whichever week of current month we're in, offset goes back
            // Find which week of the month today is
            int todayDom = now.get(Calendar.DAY_OF_MONTH);
            int currentWeekNum = (todayDom - 1) / 7; // 0-based: 0=wk1, 1=wk2 etc

            // Apply offset — each offset steps back one week, across months if needed
            Calendar anchor = (Calendar) now.clone();
            anchor.add(Calendar.WEEK_OF_YEAR, offset); // offset is ≤ 0

            int anchorYear  = anchor.get(Calendar.YEAR);
            int anchorMonth = anchor.get(Calendar.MONTH);
            int anchorDom   = anchor.get(Calendar.DAY_OF_MONTH);
            int weekNum     = (anchorDom - 1) / 7; // 0-based

            int weekStart = weekNum * 7 + 1;
            int weekEnd   = Math.min(weekStart + 6,
                    getMaxDay(anchorYear, anchorMonth));

            start.set(anchorYear, anchorMonth, weekStart, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            end.set(anchorYear, anchorMonth, weekEnd, 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);

            String label = "Week " + (weekNum + 1) + "  •  "
                    + MONTH_SHORT[anchorMonth] + " " + anchorYear;
            labelView.setText(label);

        } else if ("monthly".equals(mode)) {
            Calendar anchor = (Calendar) now.clone();
            anchor.add(Calendar.MONTH, offset);
            int y = anchor.get(Calendar.YEAR);
            int m = anchor.get(Calendar.MONTH);

            start.set(y, m, 1, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            end.set(y, m, getMaxDay(y, m), 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);

            // Label: "This Month", "Last Month", or "Jan 2025"
            int nowY = now.get(Calendar.YEAR), nowM = now.get(Calendar.MONTH);
            String label;
            if (y == nowY && m == nowM)            label = "This Month";
            else if (offset == -1)                  label = "Last Month";
            else                                    label = MONTH_SHORT[m] + " " + y;
            labelView.setText(label);

        } else { // yearly
            Calendar anchor = (Calendar) now.clone();
            anchor.add(Calendar.YEAR, offset);
            int y = anchor.get(Calendar.YEAR);

            start.set(y, Calendar.JANUARY, 1, 0, 0, 0);
            start.set(Calendar.MILLISECOND, 0);
            end.set(y, Calendar.DECEMBER, 31, 23, 59, 59);
            end.set(Calendar.MILLISECOND, 999);

            int nowY = now.get(Calendar.YEAR);
            String label;
            if (y == nowY)         label = "This Year";
            else if (offset == -1) label = "Last Year";
            else                   label = String.valueOf(y);
            labelView.setText(label);
        }

        // Disable next button if we're already at current period
        // (handled by offset < 0 check in wire methods)
        return new long[]{ start.getTimeInMillis(), end.getTimeInMillis() };
    }

    private int getMaxDay(int year, int month) {
        Calendar c = Calendar.getInstance();
        c.set(year, month, 1);
        return c.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    /** Filter transactions to a date range */
    private List<Transaction> filterByRange(long start, long end) {
        List<Transaction> result = new ArrayList<>();
        for (Transaction t : allTransactions) {
            if (t.getDate() >= start && t.getDate() <= end) result.add(t);
        }
        return result;
    }

    // ─── Donut Chart ──────────────────────────────────────────────────────────

    private void refreshDonut() {
        long[] range = getRangeAndLabel(donutMode, donutOffset, binding.tvDonutPeriod);
        List<Transaction> filtered = filterByRange(range[0], range[1]);

        // Update next button visibility
        binding.btnDonutNext.setAlpha(donutOffset < 0 ? 1f : 0.3f);

        Map<String, Float> categoryMap = new LinkedHashMap<>();
        for (Transaction t : filtered) {
            if ("expense".equals(t.getType())) {
                categoryMap.merge(t.getCategory(), (float) t.getAmount(), Float::sum);
            }
        }

        if (categoryMap.isEmpty()) {
            binding.donutChart.clear();
            binding.donutChart.setNoDataText("No expenses for this period");
            binding.donutChart.setNoDataTextColor(Color.LTGRAY);
            binding.donutChart.invalidate();
            return;
        }

        List<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Float> e : categoryMap.entrySet()) {
            entries.add(new PieEntry(e.getValue(), e.getKey()));
        }

        PieDataSet ds = new PieDataSet(entries, "");
        ds.setColors(new int[]{
            Color.parseColor("#FFC14E"), Color.parseColor("#7C6CF8"),
            Color.parseColor("#38B6FF"), Color.parseColor("#FF6B6B"),
            Color.parseColor("#00E5A0"), Color.parseColor("#C084FC"),
            Color.parseColor("#F97316"), Color.parseColor("#06B6D4")
        });
        ds.setValueTextColor(Color.WHITE);
        ds.setValueTextSize(10f);
        ds.setSliceSpace(2f);

        binding.donutChart.setData(new PieData(ds));
        binding.donutChart.setHoleRadius(55f);
        binding.donutChart.setTransparentCircleRadius(60f);
        binding.donutChart.setHoleColor(Color.parseColor("#161F30"));
        binding.donutChart.getDescription().setEnabled(false);
        binding.donutChart.setCenterText("Expenses");
        binding.donutChart.setCenterTextColor(Color.WHITE);
        binding.donutChart.setCenterTextSize(12f);
        binding.donutChart.getLegend().setTextColor(Color.LTGRAY);
        binding.donutChart.setBackgroundColor(Color.TRANSPARENT);
        binding.donutChart.animateY(800);
        binding.donutChart.invalidate();
    }

    // ─── Pie Chart ────────────────────────────────────────────────────────────

    private void refreshPie() {
        long[] range = getRangeAndLabel(pieMode, pieOffset, binding.tvPiePeriod);
        List<Transaction> filtered = filterByRange(range[0], range[1]);

        binding.btnPieNext.setAlpha(pieOffset < 0 ? 1f : 0.3f);

        double income = 0, expense = 0;
        for (Transaction t : filtered) {
            if ("income".equals(t.getType())) income  += t.getAmount();
            else                               expense += t.getAmount();
        }

        if (income == 0 && expense == 0) {
            binding.pieChart.clear();
            binding.pieChart.setNoDataText("No data for this period");
            binding.pieChart.setNoDataTextColor(Color.LTGRAY);
            binding.pieChart.invalidate();
            return;
        }

        List<PieEntry> entries = new ArrayList<>();
        if (income  > 0) entries.add(new PieEntry((float) income,  "Income"));
        if (expense > 0) entries.add(new PieEntry((float) expense, "Expenses"));

        PieDataSet ds = new PieDataSet(entries, "");
        ds.setColors(new int[]{ Color.parseColor("#00E5A0"), Color.parseColor("#FF6B6B") });
        ds.setValueTextColor(Color.WHITE);
        ds.setValueTextSize(11f);
        ds.setSliceSpace(3f);

        binding.pieChart.setData(new PieData(ds));
        binding.pieChart.setHoleRadius(50f);
        binding.pieChart.setHoleColor(Color.parseColor("#161F30"));
        binding.pieChart.getDescription().setEnabled(false);
        binding.pieChart.getLegend().setTextColor(Color.LTGRAY);
        binding.pieChart.setBackgroundColor(Color.TRANSPARENT);
        binding.pieChart.animateY(800);
        binding.pieChart.invalidate();
    }

    // ─── Line Chart ───────────────────────────────────────────────────────────

    private void refreshLine() {
        Calendar now = Calendar.getInstance();
        List<Entry> incomeEntries  = new ArrayList<>();
        List<Entry> expenseEntries = new ArrayList<>();
        String[] labels;

        if ("weekly".equals(lineMode)) {
            // Last 6 weeks
            labels = new String[6];
            for (int i = 5; i >= 0; i--) {
                Calendar anchor = (Calendar) now.clone();
                anchor.add(Calendar.WEEK_OF_YEAR, -i);
                int dom     = anchor.get(Calendar.DAY_OF_MONTH);
                int weekNum = (dom - 1) / 7;
                int wkStart = weekNum * 7 + 1;
                int wkEnd   = Math.min(wkStart + 6,
                        getMaxDay(anchor.get(Calendar.YEAR), anchor.get(Calendar.MONTH)));

                Calendar s = (Calendar) anchor.clone();
                s.set(Calendar.DAY_OF_MONTH, wkStart);
                s.set(Calendar.HOUR_OF_DAY, 0); s.set(Calendar.MINUTE, 0); s.set(Calendar.SECOND, 0); s.set(Calendar.MILLISECOND, 0);
                Calendar e = (Calendar) anchor.clone();
                e.set(Calendar.DAY_OF_MONTH, wkEnd);
                e.set(Calendar.HOUR_OF_DAY, 23); e.set(Calendar.MINUTE, 59); e.set(Calendar.SECOND, 59); e.set(Calendar.MILLISECOND, 999);

                float inc = 0, exp = 0;
                for (Transaction t : allTransactions) {
                    if (t.getDate() >= s.getTimeInMillis() && t.getDate() <= e.getTimeInMillis()) {
                        if ("income".equals(t.getType())) inc += t.getAmount();
                        else exp += t.getAmount();
                    }
                }
                int idx = 5 - i;
                incomeEntries.add(new Entry(idx, inc));
                expenseEntries.add(new Entry(idx, exp));
                labels[idx] = "Wk" + (weekNum + 1) + "\n" + MONTH_SHORT[anchor.get(Calendar.MONTH)];
            }

        } else if ("monthly".equals(lineMode)) {
            // Last 6 months
            labels = new String[6];
            for (int i = 5; i >= 0; i--) {
                Calendar anchor = (Calendar) now.clone();
                anchor.add(Calendar.MONTH, -i);
                int y = anchor.get(Calendar.YEAR), m = anchor.get(Calendar.MONTH);

                Calendar s = Calendar.getInstance(); s.set(y, m, 1, 0, 0, 0); s.set(Calendar.MILLISECOND, 0);
                Calendar e = Calendar.getInstance(); e.set(y, m, getMaxDay(y, m), 23, 59, 59); e.set(Calendar.MILLISECOND, 999);

                float inc = 0, exp = 0;
                for (Transaction t : allTransactions) {
                    if (t.getDate() >= s.getTimeInMillis() && t.getDate() <= e.getTimeInMillis()) {
                        if ("income".equals(t.getType())) inc += t.getAmount();
                        else exp += t.getAmount();
                    }
                }
                int idx = 5 - i;
                incomeEntries.add(new Entry(idx, inc));
                expenseEntries.add(new Entry(idx, exp));
                labels[idx] = MONTH_SHORT[m] + "\n" + (y % 100);
            }

        } else { // yearly
            // Last 5 years
            labels = new String[5];
            for (int i = 4; i >= 0; i--) {
                int y = now.get(Calendar.YEAR) - i;
                Calendar s = Calendar.getInstance(); s.set(y, Calendar.JANUARY, 1, 0, 0, 0); s.set(Calendar.MILLISECOND, 0);
                Calendar e = Calendar.getInstance(); e.set(y, Calendar.DECEMBER, 31, 23, 59, 59); e.set(Calendar.MILLISECOND, 999);

                float inc = 0, exp = 0;
                for (Transaction t : allTransactions) {
                    if (t.getDate() >= s.getTimeInMillis() && t.getDate() <= e.getTimeInMillis()) {
                        if ("income".equals(t.getType())) inc += t.getAmount();
                        else exp += t.getAmount();
                    }
                }
                int idx = 4 - i;
                incomeEntries.add(new Entry(idx, inc));
                expenseEntries.add(new Entry(idx, exp));
                labels[idx] = String.valueOf(y);
            }
        }

        LineDataSet incomeSet = buildLineSet(incomeEntries, "Income", "#00E5A0");
        LineDataSet expenseSet = buildLineSet(expenseEntries, "Expenses", "#FF6B6B");

        binding.lineChart.setData(new LineData(incomeSet, expenseSet));
        binding.lineChart.getDescription().setEnabled(false);
        binding.lineChart.getXAxis().setTextColor(Color.LTGRAY);
        binding.lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        binding.lineChart.getXAxis().setGranularity(1f);
        binding.lineChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        binding.lineChart.getAxisLeft().setTextColor(Color.LTGRAY);
        binding.lineChart.getAxisRight().setEnabled(false);
        binding.lineChart.getLegend().setTextColor(Color.LTGRAY);
        binding.lineChart.setBackgroundColor(Color.TRANSPARENT);
        binding.lineChart.animateXY(800, 800);
        binding.lineChart.invalidate();
    }

    private LineDataSet buildLineSet(List<Entry> entries, String label, String hex) {
        LineDataSet ds = new LineDataSet(entries, label);
        int color = Color.parseColor(hex);
        ds.setColor(color);
        ds.setCircleColor(color);
        ds.setLineWidth(2.5f);
        ds.setCircleRadius(4f);
        ds.setDrawFilled(true);
        ds.setFillColor(color);
        ds.setFillAlpha(25);
        ds.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        ds.setValueTextColor(Color.TRANSPARENT);
        return ds;
    }

    // ─── Filter UI highlight helpers ─────────────────────────────────────────

    private void setFilterUI(TextView weekly, TextView monthly, TextView yearly, String active) {
        int activeColor  = Color.parseColor("#00E5A0");
        int inactiveColor = Color.parseColor("#1A2235");
        int darkText     = Color.parseColor("#0A0E1A");
        int mutedText    = Color.parseColor("#6B7A99");

        weekly.setBackgroundResource(  "weekly".equals(active)  ? R.drawable.bg_source_selected : R.drawable.bg_source_unselected);
        monthly.setBackgroundResource( "monthly".equals(active) ? R.drawable.bg_source_selected : R.drawable.bg_source_unselected);
        yearly.setBackgroundResource(  "yearly".equals(active)  ? R.drawable.bg_source_selected : R.drawable.bg_source_unselected);

        weekly.setTextColor(  "weekly".equals(active)  ? darkText : mutedText);
        monthly.setTextColor( "monthly".equals(active) ? darkText : mutedText);
        yearly.setTextColor(  "yearly".equals(active)  ? darkText : mutedText);
    }

    private void updateDonutFilterUI() {
        setFilterUI(binding.btnDonutWeekly, binding.btnDonutMonthly, binding.btnDonutYearly, donutMode);
    }

    private void updatePieFilterUI() {
        setFilterUI(binding.btnPieWeekly, binding.btnPieMonthly, binding.btnPieYearly, pieMode);
    }

    private void updateLineFilterUI() {
        setFilterUI(binding.btnLineWeekly, binding.btnLineMonthly, binding.btnLineYearly, lineMode);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
