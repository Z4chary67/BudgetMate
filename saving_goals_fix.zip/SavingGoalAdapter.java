package com.budgetmate.app.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.budgetmate.app.databinding.ItemSavingGoalBinding;
import com.budgetmate.app.models.SavingGoal;
import com.budgetmate.app.utils.CurrencyFormatter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SavingGoalAdapter extends RecyclerView.Adapter<SavingGoalAdapter.ViewHolder> {

    public interface OnDeleteClickListener { void onDelete(SavingGoal goal); }
    public interface OnAddAmountListener  { void onAddAmount(SavingGoal goal, double amount, String source); }

    private List<SavingGoal> goals = new ArrayList<>();
    private final OnDeleteClickListener deleteListener;
    private final OnAddAmountListener   addAmountListener;

    public SavingGoalAdapter(OnDeleteClickListener deleteListener, OnAddAmountListener addAmountListener) {
        this.deleteListener    = deleteListener;
        this.addAmountListener = addAmountListener;
    }

    public void setGoals(List<SavingGoal> goals) {
        this.goals = goals != null ? goals : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(ItemSavingGoalBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.bind(goals.get(position));
    }

    @Override
    public int getItemCount() { return goals.size(); }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final ItemSavingGoalBinding b;
        private String selectedSource = "Wallet"; // default

        ViewHolder(ItemSavingGoalBinding b) {
            super(b.getRoot());
            this.b = b;
        }

        void bind(SavingGoal goal) {
            // Reset source selection to Wallet each time we bind
            selectedSource = "Wallet";
            setSourceUI("Wallet");

            b.tvGoalName.setText(goal.getEmoji() + "  " + goal.getName());
            b.tvSavedAmount.setText(CurrencyFormatter.format(goal.getSavedAmount()));
            b.tvTargetAmount.setText(CurrencyFormatter.format(goal.getTargetAmount()));
            b.tvPercent.setText(goal.getProgressPercent() + "%");
            b.progressBar.setProgress(goal.getProgressPercent());

            String deadline = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                    .format(new Date(goal.getDeadline()));
            b.tvDeadline.setText("🗓️ " + deadline);
            b.tvRemaining.setText("Remaining: " + CurrencyFormatter.format(goal.getRemainingAmount()));

            // Color progress bar green/yellow/red based on progress
            int color;
            if (goal.getProgressPercent() >= 100) color = Color.parseColor("#00E5A0");
            else if (goal.getProgressPercent() >= 60)  color = Color.parseColor("#FFC14E");
            else color = Color.parseColor("#7C6CF8");
            b.progressBar.setProgressTintList(
                android.content.res.ColorStateList.valueOf(color));

            // Source toggle
            b.btnSourceWallet.setOnClickListener(v -> {
                selectedSource = "Wallet";
                setSourceUI("Wallet");
            });
            b.btnSourceBank.setOnClickListener(v -> {
                selectedSource = "Bank";
                setSourceUI("Bank");
            });

            // Delete
            if (deleteListener != null) {
                b.btnDelete.setOnClickListener(v -> deleteListener.onDelete(goal));
            }

            // Add amount button
            b.btnAdd.setOnClickListener(v -> {
                String amountStr = b.etAmount.getText().toString().trim();
                if (amountStr.isEmpty()) {
                    Toast.makeText(b.getRoot().getContext(),
                        "Please enter an amount", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    double amount = Double.parseDouble(amountStr);
                    if (amount <= 0) {
                        Toast.makeText(b.getRoot().getContext(),
                            "Amount must be greater than 0", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (addAmountListener != null) {
                        addAmountListener.onAddAmount(goal, amount, selectedSource);
                    }
                    b.etAmount.setText("");
                    b.etAmount.clearFocus();

                    // Update UI immediately so user sees change right away
                    double newSaved = goal.getSavedAmount() + amount;
                    goal.setSavedAmount(newSaved);
                    b.tvSavedAmount.setText(CurrencyFormatter.format(newSaved));
                    b.tvRemaining.setText("Remaining: " + CurrencyFormatter.format(goal.getRemainingAmount()));
                    b.progressBar.setProgress(goal.getProgressPercent());
                    b.tvPercent.setText(goal.getProgressPercent() + "%");

                    Toast.makeText(b.getRoot().getContext(),
                        "₱" + String.format("%.2f", amount) + " added from " + selectedSource + " ✅",
                        Toast.LENGTH_SHORT).show();

                } catch (NumberFormatException e) {
                    Toast.makeText(b.getRoot().getContext(),
                        "Invalid amount", Toast.LENGTH_SHORT).show();
                }
            });
        }

        private void setSourceUI(String source) {
            int activeColor   = Color.parseColor("#00E5A0");
            int inactiveColor = Color.parseColor("#1A2235");
            int darkText      = Color.parseColor("#0A0E1A");
            int mutedText     = Color.parseColor("#6B7A99");

            if ("Wallet".equals(source)) {
                b.btnSourceWallet.setBackgroundResource(com.budgetmate.app.R.drawable.bg_source_selected);
                b.btnSourceWallet.setTextColor(darkText);
                b.btnSourceBank.setBackgroundResource(com.budgetmate.app.R.drawable.bg_source_unselected);
                b.btnSourceBank.setTextColor(mutedText);
            } else {
                b.btnSourceBank.setBackgroundResource(com.budgetmate.app.R.drawable.bg_source_selected);
                b.btnSourceBank.setTextColor(darkText);
                b.btnSourceWallet.setBackgroundResource(com.budgetmate.app.R.drawable.bg_source_unselected);
                b.btnSourceWallet.setTextColor(mutedText);
            }
        }
    }
}
