# 💰 BudgetMate — Android App

> Offline-first personal finance tracker built in **Java** with **Android Studio** (Groovy DSL)

---

## 📁 Project Structure

```
BudgetMate/
├── build.gradle                         ← Root build file (Groovy DSL)
├── settings.gradle                      ← Module settings + JitPack repo
└── app/
    ├── build.gradle                     ← App module dependencies
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/budgetmate/app/
        │   ├── activities/
        │   │   ├── SplashActivity.java
        │   │   ├── LoginActivity.java
        │   │   ├── SignupActivity.java
        │   │   ├── PinSetupActivity.java
        │   │   ├── PinLoginActivity.java
        │   │   ├── MainActivity.java          ← Navigation host + DrawerLayout
        │   │   ├── DashboardFragment.java
        │   │   ├── TransactionsFragment.java
        │   │   ├── BudgetFragment.java
        │   │   ├── SavingGoalsFragment.java
        │   │   ├── SummaryFragment.java
        │   │   └── AddTransactionFragment.java
        │   ├── adapters/
        │   │   ├── TransactionAdapter.java
        │   │   ├── BudgetAdapter.java
        │   │   └── SavingGoalAdapter.java
        │   ├── database/
        │   │   ├── BudgetMateDatabase.java    ← Room singleton
        │   │   ├── TransactionDao.java
        │   │   ├── BudgetDao.java
        │   │   └── SavingGoalDao.java
        │   ├── models/
        │   │   ├── Transaction.java
        │   │   ├── Budget.java
        │   │   └── SavingGoal.java
        │   ├── repositories/
        │   │   ├── TransactionRepository.java
        │   │   ├── BudgetRepository.java
        │   │   └── SavingGoalRepository.java
        │   ├── viewmodels/
        │   │   ├── DashboardViewModel.java
        │   │   ├── TransactionViewModel.java
        │   │   ├── BudgetViewModel.java
        │   │   └── SavingGoalViewModel.java
        │   └── utils/
        │       ├── NotificationHelper.java    ← Budget alert notifications
        │       ├── PinManager.java            ← SHA-256 PIN storage
        │       └── CurrencyFormatter.java     ← ₱ Peso formatting
        └── res/
            ├── layout/
            │   ├── activity_main.xml          ← DrawerLayout + BottomNav
            │   ├── fragment_dashboard.xml
            │   ├── fragment_transactions.xml
            │   ├── fragment_budget.xml
            │   ├── fragment_saving_goals.xml
            │   ├── fragment_summary.xml       ← PieChart, LineChart
            │   ├── item_transaction.xml
            │   ├── item_budget.xml
            │   └── item_saving_goal.xml
            ├── navigation/nav_graph.xml
            ├── menu/
            │   ├── bottom_nav_menu.xml
            │   └── drawer_menu.xml
            └── values/
                ├── colors.xml
                ├── themes.xml
                └── strings.xml
```

---

## 🚀 How to Open in Android Studio

1. **Clone / unzip** the project folder
2. Open Android Studio → **File > Open** → select `BudgetMate/` folder
3. Wait for **Gradle sync** to complete
4. Android Studio will auto-download all dependencies
5. Connect a device or start an emulator (API 26+)
6. Click ▶ **Run**

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | **Java** (100%) |
| Build System | **Gradle Groovy DSL** |
| Database | **Room** (SQLite ORM) |
| Architecture | **MVVM** (ViewModel + LiveData) |
| Navigation | **Navigation Component** |
| Charts | **MPAndroidChart** (Pie, Donut, Line) |
| UI | **Material Design 3** |
| PIN Storage | **SHA-256** hashed in SharedPreferences |
| Notifications | **NotificationManager** (in-app alerts) |

---

## ✨ Features

### 🔐 Auth
- Login & Signup (offline, name/email stored locally)
- 4-digit PIN setup with SHA-256 hashing
- PIN login with shake animation on failure
- Auto-redirect to PIN login if app was previously used

### 🏠 Dashboard
- Time-aware greeting ("Good morning/afternoon/evening, Aaron!")
- Total balance, income, expenses summary card
- **In-app budget exceeded alerts** (red banner)
- **Budget warning banner** (yellow, shows warning count)
- Quick action buttons: Add Income, Add Expense, Budget Limit, Saving Goal, Summary
- Recent transactions preview (last 5)
- Saving goals preview (top 3)
- Hamburger menu → Side drawer (Profile, About Us, Settings, Logout)

### 📋 Transactions
- All income + expenses listed
- Filter tabs: All / Income / Expense
- Calendar strip to filter by date
- Delete any transaction
- Auto-grouped by date sections

### 📊 Budget Limits
- Categories: Housing, Food & Dining, Transportation, Education, Health, Subscriptions, Utilities, Shopping, Other (custom label)
- Progress bar per category (green / yellow / red based on usage)
- Budget exceeded → system notification fires
- 80%+ usage → caution notification fires
- Monthly budget summary (total limit / spent / remaining)
- Delete budget limits

### 🎯 Saving Goals
- Set goal name, target amount, emoji, deadline
- Progress bar + percentage
- Shows saved amount, target, remaining, and weekly needed amount
- Add to goal with Wallet / Bank / Other source selector
- Delete goals

### 📈 Summary
- **Donut chart** — expenses by category
- **Pie chart** — income vs expenses split
- **Line chart** — income vs expenses trend over 6 months
- Period toggle: Week / Month / Year
- Calendar picker to select custom date range
- Powered by MPAndroidChart v3.1.0

---

## 📦 Key Dependencies (app/build.gradle)

```groovy
// Room Database
implementation 'androidx.room:room-runtime:2.6.1'
annotationProcessor 'androidx.room:room-compiler:2.6.1'

// ViewModel + LiveData
implementation 'androidx.lifecycle:lifecycle-viewmodel:2.8.0'
implementation 'androidx.lifecycle:lifecycle-livedata:2.8.0'

// Navigation
implementation 'androidx.navigation:navigation-fragment:2.7.7'
implementation 'androidx.navigation:navigation-ui:2.7.7'

// Charts
implementation 'com.github.PhilJay:MPAndroidChart:v3.1.0'

// Material Design 3
implementation 'com.google.android.material:material:1.12.0'
```

> Note: JitPack repo is required for MPAndroidChart — already added in `settings.gradle`

---

## 🎨 Color Palette

| Token | Hex | Use |
|-------|-----|-----|
| `primary` | `#00E5A0` | Income, success, active |
| `secondary` | `#7C6CF8` | Balance card, secondary |
| `accent_red` | `#FF6B6B` | Expenses, exceeded budget |
| `accent_yellow` | `#FFC14E` | Warnings, saving goals |
| `bg_dark` | `#0A0E1A` | App background |
| `card` | `#161F30` | Card backgrounds |

---

## 📝 Missing Files to Create

These layouts/drawables need to be created as well:
- `activity_login.xml`, `activity_signup.xml`, `activity_pin_setup.xml`, `activity_pin_login.xml`, `activity_splash.xml`
- `fragment_transactions.xml`, `fragment_budget.xml`, `fragment_saving_goals.xml`, `fragment_add_transaction.xml`
- `dialog_add_budget.xml`, `dialog_add_goal.xml`
- `nav_header.xml`
- Drawable resources: `bg_icon_btn.xml`, `bg_alert_red.xml`, `bg_alert_yellow.xml`, `bg_qa_green.xml`, etc.
- Vector drawables for bottom nav icons: `ic_home.xml`, `ic_transactions.xml`, `ic_budget.xml`, `ic_goals.xml`, `ic_chart.xml`
- `TransactionsFragment.java`, `SavingGoalsFragment.java`, `AddTransactionFragment.java`

All follow the same MVVM pattern shown in the provided files.
