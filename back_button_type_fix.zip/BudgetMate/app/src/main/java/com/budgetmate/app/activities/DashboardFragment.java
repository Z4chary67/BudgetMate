package com.budgetmate.app.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.budgetmate.app.R;
import com.budgetmate.app.adapters.TransactionAdapter;
import com.budgetmate.app.adapters.SavingGoalAdapter;
import com.budgetmate.app.databinding.FragmentDashboardBinding;
import com.budgetmate.app.models.Budget;
import com.budgetmate.app.utils.CurrencyFormatter;
import com.budgetmate.app.utils.PinManager;
import com.budgetmate.app.viewmodels.DashboardViewModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private DashboardViewModel viewModel;
    private TransactionAdapter transactionAdapter;
    private SavingGoalAdapter goalAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(DashboardViewModel.class);

        // Greeting
        String name = new PinManager(requireContext()).getUserName();
        String timeGreeting = getTimeGreeting();
        binding.tvGreeting.setText(timeGreeting + ", " + name + "!");

        // Adapters
        transactionAdapter = new TransactionAdapter();
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(transactionAdapter);

        goalAdapter = new SavingGoalAdapter(null, null, null, null, getViewLifecycleOwner());
        binding.rvSavingGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvSavingGoals.setAdapter(goalAdapter);

        // Balance observers
        viewModel.getTotalBalance().observe(getViewLifecycleOwner(), balance ->
            binding.tvTotalBalance.setText(CurrencyFormatter.format(balance != null ? balance : 0)));

        viewModel.getTotalIncome().observe(getViewLifecycleOwner(), income ->
            binding.tvTotalIncome.setText(CurrencyFormatter.format(income != null ? income : 0)));

        viewModel.getTotalExpenses().observe(getViewLifecycleOwner(), expenses ->
            binding.tvTotalExpenses.setText(CurrencyFormatter.format(expenses != null ? expenses : 0)));

        viewModel.getRecentTransactions().observe(getViewLifecycleOwner(), transactions ->
            transactionAdapter.setTransactions(transactions));

        viewModel.getRecentGoals().observe(getViewLifecycleOwner(), goals ->
            goalAdapter.setGoals(goals));

        // ── Budget Alert Banner + Notification Bell ──────────────────────────
        // This observer fires automatically whenever budgets or transactions
        // change — no page refresh needed.
        viewModel.getBudgetAlerts().observe(getViewLifecycleOwner(), alerts -> {
            if (alerts == null || alerts.isEmpty()) {
                // No alerts — hide banner and clear bell badge
                binding.layoutBudgetAlert.setVisibility(View.GONE);
                binding.btnNotifications.clearColorFilter();
                return;
            }

            // Count exceeded vs near
            int exceeded = 0;
            int near     = 0;
            for (Budget b : alerts) {
                if (b.isExceeded()) exceeded++;
                else near++;
            }

            // Show red banner
            binding.layoutBudgetAlert.setVisibility(View.VISIBLE);

            String alertText;
            if (exceeded > 0 && near > 0) {
                alertText = exceeded + " budget(s) exceeded, " + near + " near limit";
            } else if (exceeded > 0) {
                alertText = exceeded + " budget limit(s) exceeded!";
            } else {
                alertText = near + " budget(s) near limit (80%+)";
            }
            binding.tvBudgetAlert.setText(alertText);

            // Highlight the bell icon red to signal alerts
            binding.btnNotifications.setColorFilter(
                android.graphics.Color.parseColor("#FF6B6B"),
                android.graphics.PorterDuff.Mode.SRC_IN
            );
        });

        // Tapping the banner → navigate to Budget page
        binding.layoutBudgetAlert.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.budgetFragment));

        // Tapping the bell → same
        binding.btnNotifications.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.budgetFragment));

        // Quick Actions
        binding.btnAddIncome.setOnClickListener(v -> {
            Bundle args = new Bundle();
            args.putString("type", "income");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnAddExpense.setOnClickListener(v -> {
            Bundle args = new Bundle();
            args.putString("type", "expense");
            Navigation.findNavController(v).navigate(R.id.action_dashboard_to_addTransaction, args);
        });
        binding.btnBudgetLimit.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.budgetFragment));
        binding.btnSavingGoal.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));
        binding.btnSummary.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.summaryFragment));

        binding.tvSeeAllTransactions.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.transactionsFragment));
        binding.tvSeeAllGoals.setOnClickListener(v ->
            Navigation.findNavController(v).navigate(R.id.savingGoalsFragment));

        binding.btnMenu.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).openDrawer();
            }
        });
    }

    private String getTimeGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Good morning";
        if (hour < 17) return "Good afternoon";
        return "Good evening";
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
